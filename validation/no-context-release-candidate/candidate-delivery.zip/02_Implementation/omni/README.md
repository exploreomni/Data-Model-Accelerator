# Provisional Omni native package

Start with `../../01_Model/docs/OMNI_SETUP.md` and `../../01_Model/docs/AI_CONTEXT.md`. Resolve the literal DMA environment tokens before adding native files to a reviewed Omni development branch.

Native files: `model`, `relationships`, nine `*.view` files and three `*.topic` files. Local support: `configure_environment.py`, `semantic-bindings.json` and this README. No tenant was connected/imported/queried.

The model defines three distinct query grains: order headers, order lines and order-reason associations. Joins are explicit many-to-one left joins; header measures are not reachable from line or reason topics. Currency and business definitions remain unknown. Personal names/precise addresses/card/account fields are omitted; operational IDs remain linkable and need native permissions verification.

Static checks are reported separately in `../../03_Validation/validation/omni-static.json`. They cannot establish Snowflake execution, Omni native compatibility, security enforcement or business acceptance.
