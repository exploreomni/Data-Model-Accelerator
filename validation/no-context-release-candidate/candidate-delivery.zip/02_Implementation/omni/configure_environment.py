#!/usr/bin/env python3
"""Resolve packaging tokens to plain Omni YAML. No network, SQL or model writes."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import yaml

TOKENS = {'__DMA_TARGET_DATABASE__': 'DMA_TARGET_DATABASE', '__DMA_TARGET_SCHEMA__': 'DMA_TARGET_SCHEMA'}
NATIVE = {'model', 'relationships'}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, default=Path(__file__).resolve().parent)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    src, out = a.source.resolve(), a.output.resolve()
    if src == out or src in out.parents:
        p.error('Use a separate output directory outside the source package')
    values = {}
    for token, env in TOKENS.items():
        value = os.environ.get(env, 'DMA_CANDIDATE' if env == 'DMA_TARGET_SCHEMA' else '')
        # This candidate intentionally uses ordinary unquoted Snowflake identifiers.
        # Mixed-case quoted identifiers need a reviewed contract adjustment.
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', value):
            p.error(f'{env} must be the exact uppercase Snowflake database/schema identifier')
        values[token] = value
    files = sorted(x for x in src.iterdir() if x.is_file() and (x.name in NATIVE or x.suffix in {'.view', '.topic'}))
    if not files:
        p.error('No native Omni files in source')
    if out.exists() and any(out.iterdir()):
        p.error('Output directory must be absent or empty; do not overwrite reviewed artifacts')
    staged = {}
    for source in files:
        text = source.read_text()
        for token, value in values.items():
            text = text.replace(token, value)
        if '__DMA_' in text:
            p.error(f'Unresolved placeholder in {source.name}')
        yaml.safe_load(text)
        staged[source.name] = text
    out.mkdir(parents=True, exist_ok=True)
    for name, text in staged.items():
        (out / name).write_text(text)
    binding_path = src / 'semantic-bindings.json'
    if binding_path.exists():
        binding = json.loads(binding_path.read_text())
        for key in ('catalog', 'schema'):
            for token, value in values.items():
                binding[key] = binding[key].replace(token, value)
        (out / 'semantic-bindings.json').write_text(json.dumps(binding, indent=2) + '\n')
    print(f'Prepared {len(staged)} local native YAML files; no connection, import or execution performed.')

if __name__ == '__main__':
    main()
