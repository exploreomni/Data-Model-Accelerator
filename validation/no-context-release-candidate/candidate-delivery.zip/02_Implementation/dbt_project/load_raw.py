#!/usr/bin/env python3
"""Local CSV simulation only. Never connects to Snowflake or invokes dbt seed."""
import argparse,hashlib,json,pathlib
import duckdb

def main():
 p=argparse.ArgumentParser();p.add_argument('--raw-root',type=pathlib.Path,required=True);p.add_argument('--database',type=pathlib.Path,required=True);a=p.parse_args()
 root=a.raw_root.resolve(strict=True);files=sorted(root.glob('*/*.csv'))
 if len(files)!=15:raise SystemExit('Expected the reviewed 15 CSV files; reprofile source changes before loading.')
 a.database.parent.mkdir(parents=True,exist_ok=True)
 con=duckdb.connect(str(a.database));records=[]
 for f in files:
  if f.is_symlink():raise SystemExit('Symlink inputs are not allowed')
  schema='raw_'+f.parent.name;name=f.stem
  if not schema.replace('_','').isalnum() or not name.isalnum():raise SystemExit('Unexpected identifier')
  con.execute(f'create schema if not exists {schema}')
  con.execute(f'create or replace table {schema}.{name} as select * from read_csv(?,header=true,all_varchar=true,nullstr=\'__DMA_UNREPRESENTED_NULL_SENTINEL__\')',[str(f)])
  records.append(dict(source=f.relative_to(root).as_posix(),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),rows=con.execute(f'select count(*) from {schema}.{name}').fetchone()[0]))
 con.close();print(json.dumps(dict(scope='local_csv_snapshot_simulation',native_snowflake=False,sources=records),indent=2))
if __name__=='__main__':main()
