{% macro typed_value(expression, data_type) -%}
{{- return(adapter.dispatch('typed_value', 'blind_candidate')(expression, data_type)) -}}
{%- endmacro %}
{% macro default__typed_value(expression, data_type) -%}
{%- if data_type == 'BOOLEAN' -%}
case
        when nullif({{ expression }}, '') is null then null
        when lower({{ expression }}) = 't' then true
        when lower({{ expression }}) = 'f' then false
        else cast({{ expression }} as boolean)
    end
{%- else -%}
cast(nullif({{ expression }}, '') as {{ data_type.lower().replace(',', ', ') }})
{%- endif -%}
{%- endmacro %}
{% macro duckdb__typed_value(expression, data_type) -%}
{{- return(default__typed_value(expression, 'TIMESTAMP' if data_type == 'TIMESTAMP_NTZ' else data_type)) -}}
{%- endmacro %}
