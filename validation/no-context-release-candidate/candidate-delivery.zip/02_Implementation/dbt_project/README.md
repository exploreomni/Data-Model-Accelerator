# Blind candidate dbt project

Provisional new model derived only from the 15 supplied CSV snapshots. Business/Excel equivalence, Snowflake execution and Omni behavior are unverified. Native Snowflake warehouse/profile/grants are unavailable. All definitions need named owner review.

## Local reproduction

Run from this project directory in an isolated Python 3.12 environment. Obtain the exact 15 pinned CSVs identified in `../../01_Model/docs/source-manifest.json` and verify their hashes. Raw rows and working databases are outside this ZIP. Install the included local requirements first:

```sh
python -m pip install -r requirements-local.txt
```

The standalone loader creates an isolated DuckDB raw simulation using VARCHAR values. The model SQL and macros are the Snowflake candidate; the reviewed timestamp cast branch differs locally. Then run:

```
python load_raw.py --raw-root /absolute/approved/raw --database /absolute/local/candidate.duckdb
mkdir -p target/runtime
cp profiles.example.yml target/runtime/profiles.yml
export DMA_DUCKDB_PATH=/absolute/local/candidate.duckdb
dbt parse --no-partial-parse --profiles-dir target/runtime --target local
dbt compile --no-partial-parse --profiles-dir target/runtime --target local
dbt build --no-partial-parse --profiles-dir target/runtime --target local
```

Run commands from this project directory. These manual commands produce fresh local dbt artifacts; the archived full evidence association additionally records the supplied accelerator verifier, source hashes and complete projection evaluation.

## Snowflake development handoff

Use a separately qualified dbt-snowflake environment. Set DMA_SNOWFLAKE_ACCOUNT, DMA_SNOWFLAKE_USER, DMA_SNOWFLAKE_PRIVATE_KEY_PATH, DMA_SNOWFLAKE_ROLE, DMA_SNOWFLAKE_WAREHOUSE, DMA_TARGET_DATABASE, DMA_TARGET_SCHEMA and DMA_RAW_DATABASE. Set DMA_RAW_SALES_SCHEMA, DMA_RAW_PRODUCTION_SCHEMA, DMA_RAW_PERSON_SCHEMA and DMA_RAW_DATE_SCHEMA to existing raw schemas. Defaults are RAW_SALES, RAW_PRODUCTION, RAW_PERSON and RAW_DATE. Unquoted table/column names assume native uppercase Snowflake identifiers and need live catalogue confirmation; native quoted mixed-case inputs need an explicit mapping before execution.

`DMA_TARGET_SCHEMA` defaults to DMA_CANDIDATE; dbt's normal schema generation produces DMA_CANDIDATE_BRONZE, DMA_CANDIDATE_SILVER, DMA_CANDIDATE_GOLD. Database remains the explicitly supplied DMA_TARGET_DATABASE. Source tables must already exist. Native typed raw columns may need an agreed lexical landing contract because VARCHAR rendering can alter formatting; this extract-only candidate cannot prove native fidelity.

Gold excludes names, precise addresses, postal/spatial fields, person/card IDs, card numbers/expiry, approval codes/account numbers. Gold operational identifiers are linkable and do not establish anonymization. Restrict raw/bronze/silver and grant Omni only approved Gold access; masking/access grants and permitted/denied tests must be completed in a separately authorized environment before publication. No grants are deployed by this project.

All rows are retained. Known missing headers/person/address references remain visible; no synthetic history or unknown member is invented. Keep header and line amount topics independent. Do not aggregate unit prices, discount fractions or order amounts across reason bridges. No currency code or approved financial KPI is available. Full rebuilds represent current snapshots only; no ingestion replacement is proposed.
