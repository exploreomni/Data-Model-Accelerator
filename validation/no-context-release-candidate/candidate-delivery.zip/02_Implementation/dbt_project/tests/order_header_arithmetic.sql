select order_id
from {{ ref('fct_orders') }}
where
    abs(
        source_total_due
        - (source_subtotal + source_tax_amount + source_freight_amount)
    )
    > 0.0001
