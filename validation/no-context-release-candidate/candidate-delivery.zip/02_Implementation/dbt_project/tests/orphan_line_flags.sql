select f.order_line_id
from {{ ref('fct_order_lines') }} as f
left join {{ ref('fct_orders') }} as h on f.order_id = h.order_id
where
    f.has_order_header <> (h.order_id is not null)
    or (
        h.order_id is null
        and (
            f.customer_id is not null
            or f.order_date is not null
            or f.status_code is not null
        )
    )
