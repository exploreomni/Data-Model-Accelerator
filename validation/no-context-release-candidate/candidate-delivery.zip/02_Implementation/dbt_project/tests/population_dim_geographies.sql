select addressid as source_key
from {{ ref('stg_person__address') }}
except
select address_id
from {{ ref('dim_geographies') }}
union all
(
    select address_id from {{ ref('dim_geographies') }}
    except
    select addressid from {{ ref('stg_person__address') }}
)
