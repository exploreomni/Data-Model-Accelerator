select
    order_id,
    sales_reason_id,
    count(*) as row_count
from {{ ref('bridge_order_sales_reasons') }}
group by order_id, sales_reason_id
having count(*) > 1
