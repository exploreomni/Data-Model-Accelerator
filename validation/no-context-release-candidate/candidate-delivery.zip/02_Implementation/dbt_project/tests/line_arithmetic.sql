select order_line_id
from {{ ref('fct_order_lines') }}
where
    candidate_line_net_amount
    <> candidate_line_gross_amount - candidate_line_discount_amount
