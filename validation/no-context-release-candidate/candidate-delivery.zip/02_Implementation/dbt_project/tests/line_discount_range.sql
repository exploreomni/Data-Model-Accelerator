select order_line_id
from {{ ref('fct_order_lines') }}
where unit_discount_fraction < 0 or unit_discount_fraction > 1
