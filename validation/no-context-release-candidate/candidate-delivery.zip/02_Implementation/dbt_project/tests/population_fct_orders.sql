select salesorderid as source_key
from {{ ref('stg_sales__salesorderheader') }}
except
select order_id
from {{ ref('fct_orders') }}
union all
(
    select order_id from {{ ref('fct_orders') }}
    except
    select salesorderid from {{ ref('stg_sales__salesorderheader') }}
)
