select
    salesorderid,
    salesreasonid
from {{ ref('stg_sales__salesorderheadersalesreason') }}
except
select
    order_id,
    sales_reason_id
from {{ ref('bridge_order_sales_reasons') }}
union all
(
    select
        order_id,
        sales_reason_id
    from {{ ref('bridge_order_sales_reasons') }}
    except
    select
        salesorderid,
        salesreasonid
    from {{ ref('stg_sales__salesorderheadersalesreason') }}
)
