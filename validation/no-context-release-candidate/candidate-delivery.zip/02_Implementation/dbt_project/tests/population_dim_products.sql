select productid as source_key
from {{ ref('stg_production__product') }}
except
select product_id
from {{ ref('dim_products') }}
union all
(
    select product_id from {{ ref('dim_products') }}
    except
    select productid from {{ ref('stg_production__product') }}
)
