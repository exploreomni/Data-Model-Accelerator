select salesorderdetailid as source_key
from {{ ref('stg_sales__salesorderdetail') }}
except
select order_line_id
from {{ ref('fct_order_lines') }}
union all
(
    select order_line_id from {{ ref('fct_order_lines') }}
    except
    select salesorderdetailid from {{ ref('stg_sales__salesorderdetail') }}
)
