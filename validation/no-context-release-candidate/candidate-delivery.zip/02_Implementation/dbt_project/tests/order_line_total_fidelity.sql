with expected as (
    select
        order_id,
        count(*) as n,
        sum(candidate_line_net_amount) as amount
    from {{ ref('fct_order_lines') }}
    group by order_id
)

select f.order_id
from {{ ref('fct_orders') }} as f
left join expected as e on f.order_id = e.order_id
where
    f.observed_line_count <> coalesce(e.n, 0)
    or f.observed_line_net_amount <> e.amount
    or ((e.amount is null) <> (f.observed_line_net_amount is null))
