select h.salesorderid
from {{ ref('stg_sales__salesorderheader') }} as h
inner join {{ ref('fct_orders') }} as f on h.salesorderid = f.order_id
where
    h.subtotal <> f.source_subtotal
    or h.taxamt <> f.source_tax_amount
    or h.freight <> f.source_freight_amount
    or h.totaldue <> f.source_total_due
