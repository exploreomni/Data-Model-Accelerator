select c.customer_id
from {{ ref('dim_customers') }} as c
where
    (not c.has_person_reference and c.has_person_record)
    or (not c.has_store_reference and c.has_store_record)
