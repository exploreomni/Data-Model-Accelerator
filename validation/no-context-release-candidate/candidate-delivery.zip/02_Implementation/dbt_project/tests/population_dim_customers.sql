select customerid as source_key
from {{ ref('stg_sales__customer') }}
except
select customer_id
from {{ ref('dim_customers') }}
union all
(
    select customer_id from {{ ref('dim_customers') }}
    except
    select customerid from {{ ref('stg_sales__customer') }}
)
