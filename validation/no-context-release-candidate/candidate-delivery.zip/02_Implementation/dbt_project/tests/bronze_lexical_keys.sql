select 'br_date__date.date_day' as failed_key
from {{ ref('br_date__date') }}
where date_day = ''
union all
select 'br_person__address.addressid' as failed_key
from {{ ref('br_person__address') }}
where addressid = ''
union all
select 'br_person__countryregion.countryregioncode' as failed_key
from {{ ref('br_person__countryregion') }}
where countryregioncode = ''
union all
select 'br_person__person.businessentityid' as failed_key
from {{ ref('br_person__person') }}
where businessentityid = ''
union all
select 'br_person__stateprovince.stateprovinceid' as failed_key
from {{ ref('br_person__stateprovince') }}
where stateprovinceid = ''
union all
select 'br_production__product.productid' as failed_key
from {{ ref('br_production__product') }}
where productid = ''
union all
select 'br_production__productcategory.productcategoryid' as failed_key
from {{ ref('br_production__productcategory') }}
where productcategoryid = ''
union all
select 'br_production__productsubcategory.productsubcategoryid' as failed_key
from {{ ref('br_production__productsubcategory') }}
where productsubcategoryid = ''
union all
select 'br_sales__creditcard.creditcardid' as failed_key
from {{ ref('br_sales__creditcard') }}
where creditcardid = ''
union all
select 'br_sales__customer.customerid' as failed_key
from {{ ref('br_sales__customer') }}
where customerid = ''
union all
select 'br_sales__salesorderdetail.salesorderdetailid' as failed_key
from {{ ref('br_sales__salesorderdetail') }}
where salesorderdetailid = ''
union all
select 'br_sales__salesorderheader.salesorderid' as failed_key
from {{ ref('br_sales__salesorderheader') }}
where salesorderid = ''
union all
select 'br_sales__salesorderheadersalesreason.salesorderid' as failed_key
from {{ ref('br_sales__salesorderheadersalesreason') }}
where salesorderid = ''
union all
select 'br_sales__salesorderheadersalesreason.salesreasonid' as failed_key
from {{ ref('br_sales__salesorderheadersalesreason') }}
where salesreasonid = ''
union all
select 'br_sales__salesreason.salesreasonid' as failed_key
from {{ ref('br_sales__salesreason') }}
where salesreasonid = ''
union all
select 'br_sales__store.businessentityid' as failed_key
from {{ ref('br_sales__store') }}
where businessentityid = ''
