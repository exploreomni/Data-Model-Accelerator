select 'stg_date__date' as failed_model
where
    (select count(*) from {{ ref('br_date__date') }})
    <> (select count(*) from {{ ref('stg_date__date') }})
union all
select 'stg_person__address' as failed_model
where
    (select count(*) from {{ ref('br_person__address') }})
    <> (select count(*) from {{ ref('stg_person__address') }})
union all
select 'stg_person__countryregion' as failed_model
where
    (select count(*) from {{ ref('br_person__countryregion') }})
    <> (select count(*) from {{ ref('stg_person__countryregion') }})
union all
select 'stg_person__person' as failed_model
where
    (select count(*) from {{ ref('br_person__person') }})
    <> (select count(*) from {{ ref('stg_person__person') }})
union all
select 'stg_person__stateprovince' as failed_model
where
    (select count(*) from {{ ref('br_person__stateprovince') }})
    <> (select count(*) from {{ ref('stg_person__stateprovince') }})
union all
select 'stg_production__product' as failed_model
where
    (select count(*) from {{ ref('br_production__product') }})
    <> (select count(*) from {{ ref('stg_production__product') }})
union all
select 'stg_production__productcategory' as failed_model
where
    (select count(*) from {{ ref('br_production__productcategory') }})
    <> (select count(*) from {{ ref('stg_production__productcategory') }})
union all
select 'stg_production__productsubcategory' as failed_model
where
    (select count(*) from {{ ref('br_production__productsubcategory') }})
    <> (select count(*) from {{ ref('stg_production__productsubcategory') }})
union all
select 'stg_sales__creditcard' as failed_model
where
    (select count(*) from {{ ref('br_sales__creditcard') }})
    <> (select count(*) from {{ ref('stg_sales__creditcard') }})
union all
select 'stg_sales__customer' as failed_model
where
    (select count(*) from {{ ref('br_sales__customer') }})
    <> (select count(*) from {{ ref('stg_sales__customer') }})
union all
select 'stg_sales__salesorderdetail' as failed_model
where
    (select count(*) from {{ ref('br_sales__salesorderdetail') }})
    <> (select count(*) from {{ ref('stg_sales__salesorderdetail') }})
union all
select 'stg_sales__salesorderheader' as failed_model
where
    (select count(*) from {{ ref('br_sales__salesorderheader') }})
    <> (select count(*) from {{ ref('stg_sales__salesorderheader') }})
union all
select 'stg_sales__salesorderheadersalesreason' as failed_model
where
    (select count(*) from {{ ref('br_sales__salesorderheadersalesreason') }})
    <> (select count(*) from {{ ref('stg_sales__salesorderheadersalesreason') }})
union all
select 'stg_sales__salesreason' as failed_model
where
    (select count(*) from {{ ref('br_sales__salesreason') }})
    <> (select count(*) from {{ ref('stg_sales__salesreason') }})
union all
select 'stg_sales__store' as failed_model
where
    (select count(*) from {{ ref('br_sales__store') }})
    <> (select count(*) from {{ ref('stg_sales__store') }})
