select f.order_id
from {{ ref('fct_orders') }} as f
left join {{ ref('dim_geographies') }} as b on f.bill_to_address_id = b.address_id
left join {{ ref('dim_geographies') }} as s on f.ship_to_address_id = s.address_id
where
    f.has_bill_to_address_record <> (b.address_id is not null)
    or f.has_ship_to_address_record <> (s.address_id is not null)
