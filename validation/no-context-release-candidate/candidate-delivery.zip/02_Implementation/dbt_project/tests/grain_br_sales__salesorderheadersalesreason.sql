select
    salesorderid,
    salesreasonid,
    count(*) as row_count
from {{ ref('br_sales__salesorderheadersalesreason') }}
group by salesorderid, salesreasonid
having count(*) > 1
