select
    cast(date_day as varchar) as date_day,
    cast(prior_date_day as varchar) as prior_date_day,
    cast(next_date_day as varchar) as next_date_day,
    cast(prior_year_date_day as varchar) as prior_year_date_day,
    cast(prior_year_over_year_date_day as varchar)
        as prior_year_over_year_date_day,
    cast(day_of_week as varchar) as day_of_week,
    cast(day_of_week_name as varchar) as day_of_week_name,
    cast(day_of_month as varchar) as day_of_month,
    cast(day_of_year as varchar) as day_of_year
from {{ source('date', 'date') }}
