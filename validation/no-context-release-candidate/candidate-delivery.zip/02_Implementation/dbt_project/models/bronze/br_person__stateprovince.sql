select
    cast(stateprovinceid as varchar) as stateprovinceid,
    cast(countryregioncode as varchar) as countryregioncode,
    cast(modifieddate as varchar) as modifieddate,
    cast(rowguid as varchar) as rowguid,
    cast(name as varchar) as name,
    cast(territoryid as varchar) as territoryid,
    cast(isonlystateprovinceflag as varchar) as isonlystateprovinceflag,
    cast(stateprovincecode as varchar) as stateprovincecode
from {{ source('person', 'stateprovince') }}
