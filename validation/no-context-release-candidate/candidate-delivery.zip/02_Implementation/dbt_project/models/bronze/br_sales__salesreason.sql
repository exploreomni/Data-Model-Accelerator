select
    cast(salesreasonid as varchar) as salesreasonid,
    cast(name as varchar) as name,
    cast(reasontype as varchar) as reasontype,
    cast(modifieddate as varchar) as modifieddate
from {{ source('sales', 'salesreason') }}
