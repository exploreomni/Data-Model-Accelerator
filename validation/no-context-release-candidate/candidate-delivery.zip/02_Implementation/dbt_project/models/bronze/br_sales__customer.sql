select
    cast(customerid as varchar) as customerid,
    cast(personid as varchar) as personid,
    cast(storeid as varchar) as storeid,
    cast(territoryid as varchar) as territoryid
from {{ source('sales', 'customer') }}
