select
    cast(countryregioncode as varchar) as countryregioncode,
    cast(modifieddate as varchar) as modifieddate,
    cast(name as varchar) as name
from {{ source('person', 'countryregion') }}
