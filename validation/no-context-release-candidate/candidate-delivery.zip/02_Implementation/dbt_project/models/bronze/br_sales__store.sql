select
    cast(businessentityid as varchar) as businessentityid,
    cast(storename as varchar) as storename,
    cast(salespersonid as varchar) as salespersonid,
    cast(modifieddate as varchar) as modifieddate
from {{ source('sales', 'store') }}
