select
    cast(salesorderid as varchar) as salesorderid,
    cast(modifieddate as varchar) as modifieddate,
    cast(salesreasonid as varchar) as salesreasonid
from {{ source('sales', 'salesorderheadersalesreason') }}
