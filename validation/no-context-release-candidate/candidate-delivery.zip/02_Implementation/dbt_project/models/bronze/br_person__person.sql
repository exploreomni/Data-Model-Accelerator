select
    cast(businessentityid as varchar) as businessentityid,
    cast(title as varchar) as title,
    cast(firstname as varchar) as firstname,
    cast(middlename as varchar) as middlename,
    cast(lastname as varchar) as lastname,
    cast(persontype as varchar) as persontype,
    cast(namestyle as varchar) as namestyle,
    cast(suffix as varchar) as suffix,
    cast(modifieddate as varchar) as modifieddate,
    cast(rowguid as varchar) as rowguid,
    cast(emailpromotion as varchar) as emailpromotion
from {{ source('person', 'person') }}
