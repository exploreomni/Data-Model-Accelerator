select
    cast(productsubcategoryid as varchar) as productsubcategoryid,
    cast(productcategoryid as varchar) as productcategoryid,
    cast(name as varchar) as name,
    cast(modifieddate as varchar) as modifieddate
from {{ source('production', 'productsubcategory') }}
