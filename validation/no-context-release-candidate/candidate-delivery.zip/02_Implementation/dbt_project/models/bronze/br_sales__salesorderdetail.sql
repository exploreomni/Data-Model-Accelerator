select
    cast(salesorderid as varchar) as salesorderid,
    cast(orderqty as varchar) as orderqty,
    cast(salesorderdetailid as varchar) as salesorderdetailid,
    cast(unitprice as varchar) as unitprice,
    cast(specialofferid as varchar) as specialofferid,
    cast(modifieddate as varchar) as modifieddate,
    cast(rowguid as varchar) as rowguid,
    cast(productid as varchar) as productid,
    cast(unitpricediscount as varchar) as unitpricediscount
from {{ source('sales', 'salesorderdetail') }}
