select
    cast(addressid as varchar) as addressid,
    cast(addressline1 as varchar) as addressline1,
    cast(addressline2 as varchar) as addressline2,
    cast(city as varchar) as city,
    cast(stateprovinceid as varchar) as stateprovinceid,
    cast(postalcode as varchar) as postalcode,
    cast(spatiallocation as varchar) as spatiallocation,
    cast(rowguid as varchar) as rowguid,
    cast(modifieddate as varchar) as modifieddate
from {{ source('person', 'address') }}
