select
    cast(productcategoryid as varchar) as productcategoryid,
    cast(name as varchar) as name,
    cast(modifieddate as varchar) as modifieddate
from {{ source('production', 'productcategory') }}
