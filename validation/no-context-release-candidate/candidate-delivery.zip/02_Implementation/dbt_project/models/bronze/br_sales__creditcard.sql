select
    cast(creditcardid as varchar) as creditcardid,
    cast(cardtype as varchar) as cardtype,
    cast(expyear as varchar) as expyear,
    cast(modifieddate as varchar) as modifieddate,
    cast(expmonth as varchar) as expmonth,
    cast(cardnumber as varchar) as cardnumber
from {{ source('sales', 'creditcard') }}
