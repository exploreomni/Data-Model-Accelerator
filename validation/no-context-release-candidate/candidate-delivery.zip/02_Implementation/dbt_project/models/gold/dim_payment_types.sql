select cardtype as payment_card_type
from {{ ref('stg_sales__creditcard') }}
group by cardtype
