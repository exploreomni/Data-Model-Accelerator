select
    address_id,
    city,
    state_province_id,
    state_province_code,
    state_province_name,
    country_region_code,
    country_region_name,
    has_state_province_record,
    has_country_region_record
from {{ ref('int_geographies') }}
