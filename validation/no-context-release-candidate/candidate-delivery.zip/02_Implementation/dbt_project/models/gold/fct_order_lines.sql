select
    l.salesorderdetailid as order_line_id,
    l.salesorderid as order_id,
    l.productid as product_id,
    l.specialofferid as special_offer_id,
    l.orderqty as order_quantity,
    l.unitprice as unit_price,
    l.unitpricediscount as unit_discount_fraction,
    cast(l.orderqty * l.unitprice as decimal(38, 10))
        as candidate_line_gross_amount,
    cast(l.orderqty * l.unitprice * l.unitpricediscount as decimal(38, 10))
        as candidate_line_discount_amount,
    cast(
        l.orderqty * l.unitprice * (1 - l.unitpricediscount) as decimal(38, 10)
    ) as candidate_line_net_amount,
    l.modifieddate as source_modified_at,
    h.salesorderid is not null as has_order_header,
    p.productid is not null as has_product_record,
    h.customerid as customer_id,
    cast(h.orderdate as date) as order_date,
    h.status as status_code,
    h.currencyrateid as currency_rate_id
from {{ ref('stg_sales__salesorderdetail') }} as l
left join {{ ref('stg_sales__salesorderheader') }} as h on l.salesorderid = h.salesorderid
left join {{ ref('stg_production__product') }} as p on l.productid = p.productid
