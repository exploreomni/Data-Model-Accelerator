select
    customer_id,
    territory_id,
    store_id,
    store_name,
    person_type_code,
    has_person_reference,
    has_person_record,
    has_store_reference,
    has_store_record
from {{ ref('int_customers') }}
