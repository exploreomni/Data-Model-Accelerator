select
    r.salesorderid as order_id,
    r.salesreasonid as sales_reason_id,
    r.modifieddate as source_modified_at,
    h.salesorderid is not null as has_order_header
from {{ ref('stg_sales__salesorderheadersalesreason') }} as r
left join {{ ref('stg_sales__salesorderheader') }} as h on r.salesorderid = h.salesorderid
