select
    h.salesorderid as order_id,
    h.customerid as customer_id,
    h.billtoaddressid as bill_to_address_id,
    h.shiptoaddressid as ship_to_address_id,
    h.territoryid as territory_id,
    h.salespersonid as salesperson_id,
    h.shipmethodid as ship_method_id,
    h.currencyrateid as currency_rate_id,
    h.status as status_code,
    h.revisionnumber as revision_number,
    h.onlineorderflag as is_online_order,
    h.orderdate as order_at,
    cast(h.orderdate as date) as order_date,
    h.duedate as due_at,
    cast(h.duedate as date) as due_date,
    h.shipdate as ship_at,
    cast(h.shipdate as date) as ship_date,
    h.subtotal as source_subtotal,
    h.taxamt as source_tax_amount,
    h.freight as source_freight_amount,
    h.totaldue as source_total_due,
    coalesce(t.observed_line_count, 0) as observed_line_count,
    t.observed_line_quantity,
    t.observed_line_gross_amount,
    t.observed_line_discount_amount,
    t.observed_line_net_amount,
    cast(h.subtotal - t.observed_line_net_amount as decimal(38, 10))
        as subtotal_minus_observed_line_net,
    c.customerid is not null as has_customer_record,
    b.addressid is not null as has_bill_to_address_record,
    s.addressid is not null as has_ship_to_address_record,
    p.cardtype as payment_card_type,
    h.creditcardid is not null as has_card_reference,
    p.creditcardid is not null as has_payment_card_record,
    h.modifieddate as source_modified_at
from {{ ref('stg_sales__salesorderheader') }} as h
left join {{ ref('int_order_line_totals') }} as t on h.salesorderid = t.order_id
left join {{ ref('stg_sales__customer') }} as c on h.customerid = c.customerid
left join {{ ref('stg_person__address') }} as b on h.billtoaddressid = b.addressid
left join {{ ref('stg_person__address') }} as s on h.shiptoaddressid = s.addressid
left join {{ ref('stg_sales__creditcard') }} as p on h.creditcardid = p.creditcardid
