select
    r.salesreasonid as sales_reason_id,
    r.name as sales_reason_name,
    r.reasontype as sales_reason_type
from {{ ref('stg_sales__salesreason') }} as r
