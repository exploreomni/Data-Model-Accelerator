select
    {{ typed_value("productsubcategoryid", "VARCHAR") }} as productsubcategoryid,
    {{ typed_value("productcategoryid", "VARCHAR") }} as productcategoryid,
    {{ typed_value("name", "VARCHAR") }} as name,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate
from {{ ref('br_production__productsubcategory') }}
