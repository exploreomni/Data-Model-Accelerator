select
    salesorderid as order_id,
    count(*) as observed_line_count,
    sum(orderqty) as observed_line_quantity,
    cast(sum(orderqty * unitprice) as decimal(38, 10))
        as observed_line_gross_amount,
    cast(sum(orderqty * unitprice * unitpricediscount) as decimal(38, 10))
        as observed_line_discount_amount,
    cast(
        sum(orderqty * unitprice * (1 - unitpricediscount)) as decimal(38, 10)
    ) as observed_line_net_amount
from {{ ref('stg_sales__salesorderdetail') }}
group by salesorderid
