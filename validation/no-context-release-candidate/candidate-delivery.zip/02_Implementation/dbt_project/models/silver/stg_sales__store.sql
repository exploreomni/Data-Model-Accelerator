select
    {{ typed_value("businessentityid", "VARCHAR") }} as businessentityid,
    {{ typed_value("storename", "VARCHAR") }} as storename,
    {{ typed_value("salespersonid", "VARCHAR") }} as salespersonid,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate
from {{ ref('br_sales__store') }}
