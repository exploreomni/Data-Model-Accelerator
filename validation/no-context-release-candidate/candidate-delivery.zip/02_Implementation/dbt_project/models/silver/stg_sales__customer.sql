select
    {{ typed_value("customerid", "VARCHAR") }} as customerid,
    {{ typed_value("personid", "VARCHAR") }} as personid,
    {{ typed_value("storeid", "VARCHAR") }} as storeid,
    {{ typed_value("territoryid", "VARCHAR") }} as territoryid
from {{ ref('br_sales__customer') }}
