select
    {{ typed_value("businessentityid", "VARCHAR") }} as businessentityid,
    {{ typed_value("title", "VARCHAR") }} as title,
    {{ typed_value("firstname", "VARCHAR") }} as firstname,
    {{ typed_value("middlename", "VARCHAR") }} as middlename,
    {{ typed_value("lastname", "VARCHAR") }} as lastname,
    {{ typed_value("persontype", "VARCHAR") }} as persontype,
    {{ typed_value("namestyle", "BOOLEAN") }} as namestyle,
    {{ typed_value("suffix", "VARCHAR") }} as suffix,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("rowguid", "VARCHAR") }} as rowguid,
    {{ typed_value("emailpromotion", "VARCHAR") }} as emailpromotion
from {{ ref('br_person__person') }}
