select
    {{ typed_value("countryregioncode", "VARCHAR") }} as countryregioncode,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("name", "VARCHAR") }} as name
from {{ ref('br_person__countryregion') }}
