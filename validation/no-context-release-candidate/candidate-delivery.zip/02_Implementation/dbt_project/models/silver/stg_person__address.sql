select
    {{ typed_value("addressid", "VARCHAR") }} as addressid,
    {{ typed_value("addressline1", "VARCHAR") }} as addressline1,
    {{ typed_value("addressline2", "VARCHAR") }} as addressline2,
    {{ typed_value("city", "VARCHAR") }} as city,
    {{ typed_value("stateprovinceid", "VARCHAR") }} as stateprovinceid,
    {{ typed_value("postalcode", "VARCHAR") }} as postalcode,
    {{ typed_value("spatiallocation", "VARCHAR") }} as spatiallocation,
    {{ typed_value("rowguid", "VARCHAR") }} as rowguid,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate
from {{ ref('br_person__address') }}
