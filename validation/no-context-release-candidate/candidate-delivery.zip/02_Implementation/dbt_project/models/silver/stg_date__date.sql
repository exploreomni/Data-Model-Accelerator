select
    {{ typed_value("date_day", "DATE") }} as date_day,
    {{ typed_value("prior_date_day", "DATE") }} as prior_date_day,
    {{ typed_value("next_date_day", "DATE") }} as next_date_day,
    {{ typed_value("prior_year_date_day", "DATE") }} as prior_year_date_day,
    {{ typed_value("prior_year_over_year_date_day", "DATE") }} as prior_year_over_year_date_day,
    {{ typed_value("day_of_week", "BIGINT") }} as day_of_week,
    {{ typed_value("day_of_week_name", "VARCHAR") }} as day_of_week_name,
    {{ typed_value("day_of_month", "BIGINT") }} as day_of_month,
    {{ typed_value("day_of_year", "BIGINT") }} as day_of_year
from {{ ref('br_date__date') }}
