select
    c.customerid as customer_id,
    c.territoryid as territory_id,
    c.storeid as store_id,
    s.storename as store_name,
    p.persontype as person_type_code,
    c.personid is not null as has_person_reference,
    p.businessentityid is not null as has_person_record,
    c.storeid is not null as has_store_reference,
    s.businessentityid is not null as has_store_record
from {{ ref('stg_sales__customer') }} as c
left join {{ ref('stg_person__person') }} as p on c.personid = p.businessentityid
left join {{ ref('stg_sales__store') }} as s on c.storeid = s.businessentityid
