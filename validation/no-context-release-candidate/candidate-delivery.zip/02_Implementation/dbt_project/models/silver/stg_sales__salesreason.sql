select
    {{ typed_value("salesreasonid", "VARCHAR") }} as salesreasonid,
    {{ typed_value("name", "VARCHAR") }} as name,
    {{ typed_value("reasontype", "VARCHAR") }} as reasontype,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate
from {{ ref('br_sales__salesreason') }}
