select
    {{ typed_value("stateprovinceid", "VARCHAR") }} as stateprovinceid,
    {{ typed_value("countryregioncode", "VARCHAR") }} as countryregioncode,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("rowguid", "VARCHAR") }} as rowguid,
    {{ typed_value("name", "VARCHAR") }} as name,
    {{ typed_value("territoryid", "VARCHAR") }} as territoryid,
    {{ typed_value("isonlystateprovinceflag", "BOOLEAN") }} as isonlystateprovinceflag,
    {{ typed_value("stateprovincecode", "VARCHAR") }} as stateprovincecode
from {{ ref('br_person__stateprovince') }}
