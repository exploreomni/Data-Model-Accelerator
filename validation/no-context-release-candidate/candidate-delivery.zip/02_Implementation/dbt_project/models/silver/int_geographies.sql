select
    a.addressid as address_id,
    a.city,
    a.stateprovinceid as state_province_id,
    s.stateprovincecode as state_province_code,
    s.name as state_province_name,
    s.countryregioncode as country_region_code,
    c.name as country_region_name,
    s.stateprovinceid is not null as has_state_province_record,
    c.countryregioncode is not null as has_country_region_record
from {{ ref('stg_person__address') }} as a
left join {{ ref('stg_person__stateprovince') }} as s on a.stateprovinceid = s.stateprovinceid
left join {{ ref('stg_person__countryregion') }} as c on s.countryregioncode = c.countryregioncode
