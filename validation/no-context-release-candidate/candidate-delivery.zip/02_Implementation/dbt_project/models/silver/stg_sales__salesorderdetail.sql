select
    {{ typed_value("salesorderid", "VARCHAR") }} as salesorderid,
    {{ typed_value("orderqty", "BIGINT") }} as orderqty,
    {{ typed_value("salesorderdetailid", "VARCHAR") }} as salesorderdetailid,
    {{ typed_value("unitprice", "DECIMAL(18,4)") }} as unitprice,
    {{ typed_value("specialofferid", "VARCHAR") }} as specialofferid,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("rowguid", "VARCHAR") }} as rowguid,
    {{ typed_value("productid", "VARCHAR") }} as productid,
    {{ typed_value("unitpricediscount", "DECIMAL(9,6)") }} as unitpricediscount
from {{ ref('br_sales__salesorderdetail') }}
