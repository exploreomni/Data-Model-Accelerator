select
    {{ typed_value("salesorderid", "VARCHAR") }} as salesorderid,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("salesreasonid", "VARCHAR") }} as salesreasonid
from {{ ref('br_sales__salesorderheadersalesreason') }}
