select
    {{ typed_value("creditcardid", "VARCHAR") }} as creditcardid,
    {{ typed_value("cardtype", "VARCHAR") }} as cardtype,
    {{ typed_value("expyear", "BIGINT") }} as expyear,
    {{ typed_value("modifieddate", "TIMESTAMP_NTZ") }} as modifieddate,
    {{ typed_value("expmonth", "BIGINT") }} as expmonth,
    {{ typed_value("cardnumber", "VARCHAR") }} as cardnumber
from {{ ref('br_sales__creditcard') }}
