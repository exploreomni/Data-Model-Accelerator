select
    p.productid as product_id,
    p.name as product_name,
    p.productnumber as product_number,
    p.productsubcategoryid as subcategory_id,
    s.name as subcategory_name,
    s.productcategoryid as category_id,
    c.name as category_name,
    p.color,
    p.class as product_class_code,
    p.productline as product_line_code,
    p.finishedgoodsflag as is_finished_goods,
    p.makeflag as is_manufactured,
    p.standardcost as standard_cost,
    p.listprice as list_price,
    p.weight,
    p.weightunitmeasurecode as weight_unit_code,
    p.sellstartdate as sell_start_at,
    p.modifieddate as source_modified_at,
    s.productsubcategoryid is not null as has_subcategory_record,
    c.productcategoryid is not null as has_category_record
from {{ ref('stg_production__product') }} as p
left join
    {{ ref('stg_production__productsubcategory') }} as s
    on p.productsubcategoryid = s.productsubcategoryid
left join {{ ref('stg_production__productcategory') }} as c on s.productcategoryid = c.productcategoryid
