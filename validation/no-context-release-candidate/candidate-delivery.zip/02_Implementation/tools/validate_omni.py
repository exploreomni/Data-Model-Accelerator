#!/usr/bin/env python3
"""Fail-closed static validation of a portable Omni package against a model contract.

This is not the Omni compiler. It supports physical views with direct column
bindings, scalar aggregate measures, simple numeric expressions, and explicit
many-to-one joins. Unsupported syntax fails instead of being ignored. A generic
semantic-bindings.json adapter maps the source model contract to this surface.
The adapter is checksum-bound and each object/column binding is checked against
JSON pointers into the contract; no expected query-result files are read.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
import yaml
import sqlglot
from sqlglot import exp

NAME = re.compile(r'^[a-z][a-z0-9_]*$')
REF = re.compile(r'\$\{([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)?)\}')
PHYSICAL = re.compile(r'^"([A-Z][A-Z0-9_]*)"$')
NUMERIC = re.compile(r'^(NUMBER|DECIMAL|NUMERIC|INTEGER|INT|BIGINT|SMALLINT|FLOAT|DOUBLE|REAL)', re.I)
MODEL_KEYS = {'ai_context', 'ai_chat_topics'}
VIEW_KEYS = {'catalog', 'schema', 'table_name', 'label', 'description', 'ai_context', 'dimensions', 'measures', 'custom_compound_primary_key_sql'}
DIM_KEYS = {'sql', 'label', 'description', 'ai_context', 'primary_key', 'hidden', 'convert_tz'}
MEASURE_KEYS = {'sql', 'aggregate_type', 'label', 'description', 'ai_context'}
TOPIC_KEYS = {'base_view', 'label', 'description', 'ai_context', 'fields', 'ai_fields', 'joins'}
REL_KEYS = {'join_from_view','join_to_view','join_to_view_as','join_to_view_as_label','join_type','on_sql','relationship_type','reversible'}
AGGS = {'sum','count','count_distinct','average','min','max'}

class ValidationError(ValueError):
    pass

class UniqueLoader(yaml.SafeLoader):
    pass

def _unique(loader, node, deep=False):
    result = {}
    for k, v in node.value:
        key = loader.construct_object(k, deep=deep)
        if key in result:
            raise ValidationError(f'Duplicate YAML key: {key}')
        result[key] = loader.construct_object(v, deep=deep)
    return result
UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _unique)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pointer(data, path):
    if not isinstance(path,str) or not path.startswith('/'):
        raise ValidationError(f'Invalid contract JSON pointer: {path!r}')
    for token in path[1:].split('/'):
        token = token.replace('~1','/').replace('~0','~')
        data = data[int(token)] if isinstance(data,list) else data[token]
    return data

def require(condition, text):
    if not condition:
        raise ValidationError(text)

def mapping(value, label):
    require(isinstance(value,dict), f'{label} must be a mapping')
    return value

def keys(value, allowed, label):
    require(not(set(value)-allowed),f'{label}: unsupported parameters {sorted(set(value)-allowed)}')

def refs(sql, view):
    found = REF.findall(sql)
    require('${' not in REF.sub('',sql),f'Unsupported field reference in {view}: {sql}')
    return [x if '.' in x else view+'.'+x for x in found]

def native_files(root):
    return sorted(p for p in root.iterdir() if p.is_file() and (p.name in {'model','relationships'} or p.suffix in {'.view','.topic'}))

def read_package(root):
    result={}
    for p in native_files(root):
        result[p.name]=yaml.load(p.read_text(),Loader=UniqueLoader)
    return result

def check(package, binding, contract):
    """Return coverage metadata, or raise on the first unsupported/invalid fact."""
    expected={'model','relationships'} | {x+'.view' for x in binding['views']} | {x+'.topic' for x in binding['topics']}
    require(set(package)==expected,f'Native filename inventory differs: missing={sorted(expected-set(package))}, extra={sorted(set(package)-expected)}')
    model=mapping(package['model'],'model'); keys(model,MODEL_KEYS,'model')
    require(isinstance(model.get('ai_context'),str) and model['ai_context'].strip(),'Missing model ai_context')
    require(set(model.get('ai_chat_topics',[]))==set(binding['topics']),'Model AI topic allowlist differs from contract adapter')
    fields={}; datasets={}; stats={'views':0,'dimensions':0,'measures':0,'relationships':0,'topics':0,'topic_fields':0,'contract_column_bindings':0,'snowflake_sql_expressions':0}
    for vn,vb in binding['views'].items():
        require(bool(NAME.fullmatch(vn)),f'Invalid view name {vn}')
        require(pointer(contract,vb['object_pointer'])==vb['object_name'],f'{vn}: stale object binding')
        require(pointer(contract,vb['physical_name_pointer'])==vb['physical_name_value'],f'{vn}: physical contract changed')
        require(vb['physical_name_value'].rsplit('.',1)[-1]==vb['table_name'],f'{vn}: table is not contract physical object')
        # Privacy authorization is explicit in the adapter and source contract.
        require(vb['publication']=='consumer_allowlist',f'{vn}: no explicit consumer publication policy')
        v=mapping(package[vn+'.view'],vn); keys(v,VIEW_KEYS,vn)
        require(v.get('table_name')==vb['table_name'],f'{vn}: physical table differs')
        require(v.get('catalog')==binding['catalog'] and v.get('schema')==binding['schema'],f'{vn}: environment mapping differs')
        dims=mapping(v.get('dimensions'),vn+'.dimensions'); measures=mapping(v.get('measures',{}),vn+'.measures')
        require(not(set(dims)&set(measures)),f'{vn}: duplicate dimension and measure name')
        require(set(dims)==set(vb['columns']),f'{vn}: dimension publication allowlist differs')
        pks=[]
        for fn,d in dims.items():
            require(bool(NAME.fullmatch(fn)),f'Invalid dimension {vn}.{fn}')
            keys(mapping(d,f'{vn}.{fn}'),DIM_KEYS,f'{vn}.{fn}')
            cb=vb['columns'][fn]
            require(pointer(contract,cb['name_pointer'])==cb['source_name'],f'{vn}.{fn}: contract column missing or changed')
            dtype=pointer(contract,cb['type_pointer'])
            require(dtype==cb['data_type'],f'{vn}.{fn}: contract type differs')
            if cb.get('publication_pointer'):
                require(pointer(contract,cb['publication_pointer'])==cb['publication_value'],f'{vn}.{fn}: contract publication changed')
            require(cb.get('consumer_allowed') is True,f'{vn}.{fn}: not consumer-allowed')
            require(cb['physical_column']==cb['source_name'].upper(),f'{vn}.{fn}: physical column case/name differs from source contract')
            require(fn not in binding.get('prohibited_columns',[]),f'{vn}.{fn}: prohibited column')
            match=PHYSICAL.fullmatch(d.get('sql',''))
            require(match and match[1]==cb['physical_column'],f'{vn}.{fn}: unsupported or incorrect direct physical SQL')
            parsed=sqlglot.parse_one(d['sql'],read='snowflake')
            require(isinstance(parsed,exp.Column),f'{vn}.{fn}: not a scalar physical column')
            if d.get('primary_key') is True:pks.append(fn)
            if 'primary_key' in d:require(isinstance(d['primary_key'],bool),f'{vn}.{fn}: primary_key is not boolean')
            if 'convert_tz' in d:require(d['convert_tz'] is False,f'{vn}.{fn}: unsupported timezone conversion')
            fields[vn+'.'+fn]={'kind':'dimension','type':dtype,'definition':d,'view':vn}
            stats['dimensions']+=1;stats['contract_column_bindings']+=1;stats['snowflake_sql_expressions']+=1
        if len(vb['primary_key_fields']) > 1:
            require(not pks and v.get('custom_compound_primary_key_sql')==vb['primary_key_fields'],f'{vn}: compound primary key differs')
        else:
            require(pks==vb['primary_key_fields'] and 'custom_compound_primary_key_sql' not in v,f'{vn}: primary key differs from binding')
        require(pointer(contract,vb['primary_key_pointer'])==vb['primary_key_value'],f'{vn}: contract primary key changed')
        require(set(measures)==set(vb.get('measures',{})),f'{vn}: measure allowlist differs')
        for fn,m in measures.items():
            require(bool(NAME.fullmatch(fn)),f'Invalid measure {vn}.{fn}')
            keys(mapping(m,f'{vn}.{fn}'),MEASURE_KEYS,f'{vn}.{fn}')
            mb=vb['measures'][fn]
            require(m.get('sql')==mb['sql'] and m.get('aggregate_type')==mb.get('aggregate_type'),f'{vn}.{fn}: formula or aggregation differs from reviewed adapter')
            require(isinstance(m.get('ai_context'),str) and m['ai_context'].strip(),f'{vn}.{fn}: missing AI usage contract')
            fields[vn+'.'+fn]={'kind':'measure','type':'NUMBER','definition':m,'view':vn}
            stats['measures']+=1
        datasets[vn]=vb['object_name'];stats['views']+=1
    # Validate references/types only after the complete field symbol table exists.
    active=set();validated=set()
    def numeric_expression(node, symbols):
        if isinstance(node,exp.Column):
            require(node.name in symbols,'Unknown SQL identifier in measure expression')
            require(NUMERIC.match(symbols[node.name]),'Numeric arithmetic references a non-numeric field')
            return
        if isinstance(node,exp.Literal):
            require(not node.is_string,'String literal in numeric measure')
            return
        if isinstance(node,(exp.Paren,exp.Neg)):
            numeric_expression(node.this,symbols);return
        if isinstance(node,(exp.Add,exp.Sub,exp.Mul,exp.Div,exp.Nullif)):
            numeric_expression(node.this,symbols);numeric_expression(node.expression,symbols);return
        raise ValidationError(f'Unsupported measure expression AST: {type(node).__name__}')
    def validate_field(ref):
        require(ref in fields,f'Unresolved reference {ref}')
        if ref in validated:return
        require(ref not in active,f'Cyclic field definition {ref}')
        active.add(ref);f=fields[ref]
        if f['kind']=='measure':
            d=f['definition'];sql=d.get('sql','');rs=refs(sql,f['view']);agg=d.get('aggregate_type')
            for r in rs:
                require(r in fields,f'{ref}: missing field {r}')
                require(fields[r]['view']==f['view'],f'{ref}: cross-view measure dependency outside bounded subset')
                validate_field(r)
            if agg:
                require(agg in AGGS,f'{ref}: unsupported aggregate {agg}')
                require(len(rs)==1 and REF.fullmatch(sql),f'{ref}: aggregate input must be one dimension reference')
                require(fields[rs[0]]['kind']=='dimension',f'{ref}: nested aggregate reference')
                if agg in {'sum','average'}:require(bool(NUMERIC.match(fields[rs[0]]['type'])),f'{ref}: non-numeric aggregate input')
                if agg in {'min','max'}:f['type']=fields[rs[0]]['type']
            else:
                require(rs and all(fields[r]['kind']=='measure' for r in rs),f'{ref}: compound measures must use aggregate measures')
            names={r:'omni_ref_'+str(i) for i,r in enumerate(rs)}
            normalized=REF.sub(lambda m:names[m[1] if '.' in m[1] else f['view']+'.'+m[1]],sql)
            ast=sqlglot.parse_one(normalized,read='snowflake')
            if not agg:numeric_expression(ast,{names[r]:fields[r]['type'] for r in rs})
            else:require(isinstance(ast,exp.Column),f'{ref}: aggregate input is not scalar')
            stats['snowflake_sql_expressions']+=1
        active.remove(ref);validated.add(ref)
    for f in fields:validate_field(f)
    relations=package['relationships'];require(isinstance(relations,list),'relationships must be a top-level list')
    expected_rel=binding['relationships'];require(len(relations)==len(expected_rel),'Relationship inventory differs')
    edges={}
    for i,(r,b) in enumerate(zip(relations,expected_rel)):
        keys(mapping(r,f'relationship[{i}]'),REL_KEYS,f'relationship[{i}]')
        require(r==b['native'],f'Relationship {i}: native declaration differs from contract adapter')
        require(pointer(contract,b['contract_pointer'])==b['contract_value'],f'Relationship {i}: source contract changed')
        require(r['join_from_view'] in datasets and r['join_to_view'] in datasets,'Relationship view missing')
        require(r['join_type']=='always_left' and r['relationship_type']=='many_to_one' and not r.get('reversible',False),'Only forward many-to-one left joins permitted')
        alias=r.get('join_to_view_as',r['join_to_view']);src=r['join_from_view'];dst=r['join_to_view']
        require((src,alias) not in edges,'Duplicate relationship edge')
        pairs=[]
        for term in re.split(r'\s+AND\s+',r['on_sql']):
            m=re.fullmatch(r'\$\{('+re.escape(src)+r'\.[a-z][a-z0-9_]*)\}\s*=\s*\$\{('+re.escape(alias)+r'\.[a-z][a-z0-9_]*)\}',term)
            require(m is not None,'Unsupported relationship SQL; require declared equality keys')
            left,right=m.groups();right_physical=dst+'.'+right.split('.',1)[1]
            require(left in fields and right_physical in fields,'Relationship field missing')
            require(fields[left]['kind']==fields[right_physical]['kind']=='dimension','Join keys must be dimensions')
            require(fields[left]['type']==fields[right_physical]['type'],'Join key types differ')
            pairs.append([left.split('.',1)[1],right.split('.',1)[1]])
        require(pairs==b['key_pairs'],'Relationship keys differ from bound key pairs')
        source_relation=pointer(contract,b['contract_pointer'])
        require(datasets[src]==source_relation['from_model'] and datasets[dst]==source_relation['to_model'],'Native relationship direction differs from model contract')
        require(pairs==[list(x) for x in zip(source_relation['from_columns'],source_relation['to_columns'])],'Native key pairs differ from model contract')
        require(source_relation['cardinality']=='many_to_one' and source_relation['join']=='left','Native relationship cardinality/join differs from model contract')
        require([p[1] for p in pairs]==binding['views'][dst]['primary_key_fields'],'Join target does not cover primary key exactly')
        edges[(src,alias)]=dst;stats['relationships']+=1
    for tn,tb in binding['topics'].items():
        t=mapping(package[tn+'.topic'],tn);keys(t,TOPIC_KEYS,tn)
        require(t['base_view']==tb['base_view'],f'{tn}: base view changed')
        scope={t['base_view']:t['base_view']}
        def visit(parent,joins):
            require(isinstance(joins,dict),'Topic joins must be nested mappings')
            for alias,children in joins.items():
                require((scope[parent],alias) in edges,f'{tn}: undeclared or reverse join {parent} -> {alias}')
                require(alias not in scope,f'{tn}: repeated alias')
                scope[alias]=edges[(scope[parent],alias)]
                visit(alias,children)
        visit(t['base_view'],t.get('joins',{}))
        require(t.get('joins',{})==tb.get('joins',{}),f'{tn}: topic join graph differs')
        require(t.get('fields')==tb['fields'],f'{tn}: explicit topic field allowlist changed')
        require(isinstance(t.get('ai_context'),str) and t['ai_context'].strip(),f'{tn}: missing topic context')
        for key in ['fields','ai_fields']:
            require(isinstance(t.get(key),list) and len(t[key])==len(set(t[key])),f'{tn}: missing/duplicate {key}')
            for ref in t[key]:
                require(isinstance(ref,str) and '.' in ref,f'{tn}: wildcard/unsupported {key}')
                vn,fn=ref.split('.',1)
                require(vn in scope and scope[vn]+'.'+fn in fields,f'{tn}: unresolved or out-of-topic field {ref}')
                if key=='ai_fields':require(ref in t['fields'],f'{tn}: AI field outside topic allowlist')
            if key=='fields':stats['topic_fields']+=len(t[key])
        for ref in t['fields']:
            vn,fn=ref.split('.',1);physical=scope[vn]+'.'+fn
            f=fields[physical]
            if f['kind']=='measure':
                require(vn==t['base_view'],f'{tn}: joined-view measure risks grain mixing')
                for dep in refs(f['definition']['sql'],vn):require(dep in t['fields'],f'{tn}: measure input excluded by runtime fields restriction')
        stats['topics']+=1
    return stats

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--contract',type=Path,required=True)
    p.add_argument('--omni-dir',type=Path,required=True)
    p.add_argument('--bindings',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--negative-controls',action='store_true')
    a=p.parse_args();bp=a.bindings or a.omni_dir/'semantic-bindings.json'
    result={'validator':'generic-bounded-omni-static-v1','native_omni_validation':'not_run','snowflake_execution':'not_run','business_acceptance':'not_established','errors':[]}
    try:
        contract=json.loads(a.contract.read_text());binding=json.loads(bp.read_text())
        require(binding['contract_sha256']==sha(a.contract),'Model contract hash mismatch; refresh reviewed bindings')
        package=read_package(a.omni_dir)
        result['coverage']=check(package,binding,contract)
        result['negative_controls']=[]
        if a.negative_controls:
            # Alter both YAML and adapter formulas so reference/type controls reach
            # independent semantic checks rather than just the equality guard.
            controls=[]
            first_view=next(iter(binding['views']));first_dim=next(iter(binding['views'][first_view]['columns']))
            def missing_column(pkg,bind):
                pkg[first_view+'.view']['dimensions'][first_dim]['sql']='"MISSING_COLUMN"'
            controls.append(('missing_physical_column',missing_column,'incorrect direct physical SQL'))
            with_measure=next((v for v,b in binding['views'].items() if b.get('measures')),None)
            if with_measure:
                first_measure=next(iter(binding['views'][with_measure]['measures']))
                def dangling(pkg,bind):
                    for d in [pkg[with_measure+'.view']['measures'][first_measure],bind['views'][with_measure]['measures'][first_measure]]:d['sql']='${no_such_field}'
                controls.append(('dangling_measure_reference',dangling,'missing field'))
                def bad_agg(pkg,bind):
                    for d in [pkg[with_measure+'.view']['measures'][first_measure],bind['views'][with_measure]['measures'][first_measure]]:d['aggregate_type']='invented_sum'
                controls.append(('unsupported_aggregate',bad_agg,'unsupported aggregate'))
                def sum_string(pkg,bind):
                    column=next(n for n,d in bind['views'][with_measure]['columns'].items() if not NUMERIC.match(d['data_type']))
                    for d in [pkg[with_measure+'.view']['measures'][first_measure],bind['views'][with_measure]['measures'][first_measure]]:
                        d['sql']='${'+with_measure+'.'+column+'}';d['aggregate_type']='sum'
                controls.append(('sum_non_numeric_key',sum_string,'non-numeric aggregate input'))
            if binding['relationships']:
                def fanout(pkg,bind):
                    pkg['relationships'][0]['relationship_type']='one_to_many';bind['relationships'][0]['native']['relationship_type']='one_to_many'
                controls.append(('fanout_relationship',fanout,'forward many-to-one'))
            topic=next(iter(binding['topics']))
            def private_field(pkg,bind):pkg[topic+'.topic']['fields'].append('private.cardnumber')
            controls.append(('unpublished_topic_field',private_field,'field allowlist changed'))
            for name,mutate,reason in controls:
                altered=copy.deepcopy(package);adapter=copy.deepcopy(binding);mutate(altered,adapter)
                try:check(altered,adapter,contract)
                except ValidationError as error:
                    require(reason in str(error),f'Negative control {name} failed for unrelated reason: {error}')
                    result['negative_controls'].append({'name':name,'detected':True,'reason':str(error)})
                else:raise ValidationError(f'Negative control was not detected: {name}')
        result['status']='pass'
        result['contract_sha256']=sha(a.contract)
        result['validator_sha256']=sha(Path(__file__))
        result['dependency_versions']={'PyYAML':yaml.__version__,'sqlglot':sqlglot.__version__}
        result['environment_resolution']={'catalog':binding['catalog'],'schema':binding['schema'],'unresolved_packaging_tokens':any('__DMA_' in binding[k] for k in ('catalog','schema'))}
        result['bindings_sha256']=sha(bp)
        result['files']=[{'path':str(x.relative_to(a.omni_dir)),'sha256':sha(x)} for x in native_files(a.omni_dir)]
        result['limitations']=['Static supported-subset checks only; not Omni native compilation, live warehouse existence, access enforcement or AI answer correctness.','Contract and adapter hashes bind the package; they do not authenticate business approval.','Expected query-result/oracle files are never read.']
    except Exception as e:
        result['status']='fail';result['errors'].append(str(e))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','coverage','errors') if k in result},indent=2))
    return 0 if result['status']=='pass' else 1

if __name__=='__main__':
    sys.exit(main())
