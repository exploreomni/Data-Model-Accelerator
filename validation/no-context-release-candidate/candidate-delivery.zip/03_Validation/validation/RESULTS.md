# Release-candidate test results

Local model and semantic replay passed. High confidence for the supplied snapshot; business and native runtime qualification remain pending.

| Check | Evidence |
| --- | --- |
| Input coverage | 15 CSVs / 120 fields / 54,068 rows; hashes match the earlier frozen acquisition |
| dbt execution | 43 models + 105 tests passed; 393 model columns fully evaluated |
| Snowflake adapter | dbt-core 1.12.4 / dbt-snowflake 1.12.1; 148 nodes parsed and compiled offline; no connection attempts |
| Dictionary / ERDs | 15 raw objects + 43 models, 513 columns; 525 independent parsed-projection and lineage checks passed |
| Independent source/model checks | Exact lexical Bronze preservation; normalized Silver values; all Gold entity populations and mapped values; 13 aggregate slice groups |
| Native Omni files | 9 views / 3 topics / 11 joins / 15 measures / 99 dimensions; 6 static negative controls |
| Actual Omni YAML local replay | 52 measure cases; 11 per-key join roles; 3 topic grains; 99 dimensions; 8 grouped-query cases |
| Defect detection | 5 physical + 3 semantic mutations detected by the intended assertions |
| Conventions | 231 files / 148 units; 415 exact-file policy exceptions for 855 retained raw convention findings |
| Extracted ZIP replay | Shipped dbt project rebuilt all 148 nodes; all 43 table results match; Omni namespace resolver and static checker pass |
| Cloud / acceptance | Snowflake server, Omni tenant, grants, live AI answers and owner sign-off not performed |

The timestamp oracle defect and narrow source-verified normalization erratum remain documented; no candidate change was made to match that faulty parser. The final authored style cleanup preserved identical schemas and duplicate-aware rows for all 43 models. Code convention exceptions are not approval or semantic proof.

See [the independent report](INDEPENDENT_REVIEW.md), [lint summary](lint-summary.json), [raw lint findings](lint-findings.json), and [the runbook](../../01_Model/docs/RUNBOOK.md).
