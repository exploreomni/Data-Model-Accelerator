# Bronze model contract

Raw remains external. Fifteen bronze views preserve every source column as lexical VARCHAR, including empty strings. This is a seed-snapshot contract, not proof of Snowflake native type fidelity. A real catalogue must confirm quoted identifiers, types and source visibility before use. No source ingestion, deletion handling or ingestion timestamps are invented. Raw storage plus its bronze projections are both included in the ERD.

## Operations and evidence

Run order follows dbt source/ref dependencies: external raw → bronze → silver staging → silver intermediates → gold. Bronze and silver are views; gold tables rebuild from the current supplied snapshots. No incremental schedule or production SLA is configured. Source modified timestamps do not establish freshness, CDC order or history. Late arrivals are reflected on a later full rebuild; deletes/history cannot be inferred from one extract.

Business and operational owners, tenant boundaries, retention, timezone, currency and access personas are unknown. Restrict raw/bronze/silver; only reviewed gold relations may be granted to the Omni role. Consumer identifiers remain linkable. Local allowlist checks do not establish actual Snowflake grants or masking.

Recovery: keep the pinned raw snapshot and last accepted code; build an isolated development schema, compare the independent benchmark, then cut over consumers only after separate target and owner approval. On failure keep consumers on the previous accepted relations. No destructive rollback SQL is included.

Monitoring before live use: failed casts and keys, complete row populations, orphan rates, amount reconciliation, schema drift, source freshness and allowed/denied access personas. Known source gaps are reported, not automatically repaired.

See [the complete column dictionary](DATA_DICTIONARY.md), [the layer ERD](ERD_BRONZE.svg), [the deployment runbook](RUNBOOK.md), and [AI context](AI_CONTEXT.md).

## Object contracts

### raw:date.date

External simulated raw table represented by inputs/raw/date/date.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_DATE_SCHEMA}.DATE`
- Grain: One supplied date.date snapshot row; candidate identity date_day
- Key: date_day (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:person.address

External simulated raw table represented by inputs/raw/person/address.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.ADDRESS`
- Grain: One supplied person.address snapshot row; candidate identity addressid
- Key: addressid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:person.countryregion

External simulated raw table represented by inputs/raw/person/countryregion.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.COUNTRYREGION`
- Grain: One supplied person.countryregion snapshot row; candidate identity countryregioncode
- Key: countryregioncode (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:person.person

External simulated raw table represented by inputs/raw/person/person.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.PERSON`
- Grain: One supplied person.person snapshot row; candidate identity businessentityid
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:person.stateprovince

External simulated raw table represented by inputs/raw/person/stateprovince.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.STATEPROVINCE`
- Grain: One supplied person.stateprovince snapshot row; candidate identity stateprovinceid
- Key: stateprovinceid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:production.product

External simulated raw table represented by inputs/raw/production/product.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCT`
- Grain: One supplied production.product snapshot row; candidate identity productid
- Key: productid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:production.productcategory

External simulated raw table represented by inputs/raw/production/productcategory.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCTCATEGORY`
- Grain: One supplied production.productcategory snapshot row; candidate identity productcategoryid
- Key: productcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:production.productsubcategory

External simulated raw table represented by inputs/raw/production/productsubcategory.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCTSUBCATEGORY`
- Grain: One supplied production.productsubcategory snapshot row; candidate identity productsubcategoryid
- Key: productsubcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.creditcard

External simulated raw table represented by inputs/raw/sales/creditcard.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.CREDITCARD`
- Grain: One supplied sales.creditcard snapshot row; candidate identity creditcardid
- Key: creditcardid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.customer

External simulated raw table represented by inputs/raw/sales/customer.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.CUSTOMER`
- Grain: One supplied sales.customer snapshot row; candidate identity customerid
- Key: customerid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.salesorderdetail

External simulated raw table represented by inputs/raw/sales/salesorderdetail.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERDETAIL`
- Grain: One supplied sales.salesorderdetail snapshot row; candidate identity salesorderdetailid
- Key: salesorderdetailid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.salesorderheader

External simulated raw table represented by inputs/raw/sales/salesorderheader.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERHEADER`
- Grain: One supplied sales.salesorderheader snapshot row; candidate identity salesorderid
- Key: salesorderid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.salesorderheadersalesreason

External simulated raw table represented by inputs/raw/sales/salesorderheadersalesreason.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERHEADERSALESREASON`
- Grain: One supplied sales.salesorderheadersalesreason snapshot row; candidate identity salesorderid, salesreasonid
- Key: salesorderid, salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.salesreason

External simulated raw table represented by inputs/raw/sales/salesreason.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESREASON`
- Grain: One supplied sales.salesreason snapshot row; candidate identity salesreasonid
- Key: salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### raw:sales.store

External simulated raw table represented by inputs/raw/sales/store.csv; native catalogue not observed

- Physical: `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.STORE`
- Grain: One supplied sales.store snapshot row; candidate identity businessentityid
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: Supplied raw CSV snapshot; no source system connection
 - Materialization: external raw table (simulated)
- Refresh/history: Unknown; no ingestion is created; One supplied extract; no replication/history evidence
- Ownership: Unknown; no SME available
- Recovery: Preserve pinned CSV source; production raw recovery unknown

### br_date__date

Lexical preservation of every field in date.date; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_DATE__DATE`
- Grain: One supplied date.date snapshot row; candidate identity date_day
- Key: date_day (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:date.date
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_person__address

Lexical preservation of every field in person.address; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PERSON__ADDRESS`
- Grain: One supplied person.address snapshot row; candidate identity addressid
- Key: addressid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:person.address
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_person__countryregion

Lexical preservation of every field in person.countryregion; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PERSON__COUNTRYREGION`
- Grain: One supplied person.countryregion snapshot row; candidate identity countryregioncode
- Key: countryregioncode (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:person.countryregion
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_person__person

Lexical preservation of every field in person.person; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PERSON__PERSON`
- Grain: One supplied person.person snapshot row; candidate identity businessentityid
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:person.person
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_person__stateprovince

Lexical preservation of every field in person.stateprovince; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PERSON__STATEPROVINCE`
- Grain: One supplied person.stateprovince snapshot row; candidate identity stateprovinceid
- Key: stateprovinceid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:person.stateprovince
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_production__product

Lexical preservation of every field in production.product; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PRODUCTION__PRODUCT`
- Grain: One supplied production.product snapshot row; candidate identity productid
- Key: productid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:production.product
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_production__productcategory

Lexical preservation of every field in production.productcategory; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PRODUCTION__PRODUCTCATEGORY`
- Grain: One supplied production.productcategory snapshot row; candidate identity productcategoryid
- Key: productcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:production.productcategory
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_production__productsubcategory

Lexical preservation of every field in production.productsubcategory; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_PRODUCTION__PRODUCTSUBCATEGORY`
- Grain: One supplied production.productsubcategory snapshot row; candidate identity productsubcategoryid
- Key: productsubcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:production.productsubcategory
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__creditcard

Lexical preservation of every field in sales.creditcard; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__CREDITCARD`
- Grain: One supplied sales.creditcard snapshot row; candidate identity creditcardid
- Key: creditcardid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.creditcard
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__customer

Lexical preservation of every field in sales.customer; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__CUSTOMER`
- Grain: One supplied sales.customer snapshot row; candidate identity customerid
- Key: customerid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.customer
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__salesorderdetail

Lexical preservation of every field in sales.salesorderdetail; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__SALESORDERDETAIL`
- Grain: One supplied sales.salesorderdetail snapshot row; candidate identity salesorderdetailid
- Key: salesorderdetailid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.salesorderdetail
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__salesorderheader

Lexical preservation of every field in sales.salesorderheader; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__SALESORDERHEADER`
- Grain: One supplied sales.salesorderheader snapshot row; candidate identity salesorderid
- Key: salesorderid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.salesorderheader
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__salesorderheadersalesreason

Lexical preservation of every field in sales.salesorderheadersalesreason; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__SALESORDERHEADERSALESREASON`
- Grain: One supplied sales.salesorderheadersalesreason snapshot row; candidate identity salesorderid, salesreasonid
- Key: salesorderid, salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.salesorderheadersalesreason
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__salesreason

Lexical preservation of every field in sales.salesreason; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__SALESREASON`
- Grain: One supplied sales.salesreason snapshot row; candidate identity salesreasonid
- Key: salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.salesreason
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### br_sales__store

Lexical preservation of every field in sales.store; no ingestion replacement

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_BRONZE.BR_SALES__STORE`
- Grain: One supplied sales.store snapshot row; candidate identity businessentityid
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: raw:sales.store
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

