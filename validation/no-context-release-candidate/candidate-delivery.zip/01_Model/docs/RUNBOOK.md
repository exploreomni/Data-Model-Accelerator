# Run the dbt → Snowflake → Omni candidate

This is a runnable, provisional model from raw snapshots. The delivery has local execution evidence and an offline Snowflake adapter check. It has **not connected to a Snowflake account or an Omni tenant**. Business meaning and target access still need review. The ZIP includes real project files; dbt SQL containing `ref()`/`source()` must run through dbt.

## 1. Open and review

Unzip the package and open `START_HERE.html`. Read the model overview, decisions and validation tabs. Use the files tab to preview or copy code. The full dbt project is in `02_Implementation/dbt_project`; native Omni files are in `02_Implementation/omni`. Model and layer documentation is in `01_Model/docs`; validation summaries are in `03_Validation/validation`.

The model preserves source rows, including known missing references. Six dimensions, separate order/line facts, and a reason bridge are proposed. Amounts have no proven currency or accounting definition. Current snapshots cannot establish historical as-of behavior. Read [the data dictionary](DATA_DICTIONARY.md) and [AI context](AI_CONTEXT.md) before interpreting metrics.

## 2. Select an isolated Snowflake development target

After review, an operator chooses a development database/base schema, raw database and source schemas. Confirm all 15 tables and 120 source columns against the actual catalogue. CSV text types, names and case are simulation assumptions. Quoted mixed-case names or typed source columns need explicit source mappings before executing. The source layer must already exist; this project does not replace ingestion or run `dbt seed` against Snowflake.

Use a least-privilege transformation role with read access to the selected raw tables and build privileges in the selected development schemas. Create/use a separate Omni role with approved Gold access only. Actual grants and allowed/denied access tests remain pending. No credentials belong in the ZIP or git repository.

## 3. Configure dbt

From `02_Implementation/dbt_project`, create a Python 3.12 virtual environment and install the pinned Snowflake adapter requirements:

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-snowflake.txt
mkdir -p target/runtime
cp profiles.example.yml target/runtime/profiles.yml
```

Set these environment variables through your normal credential mechanism: `DMA_SNOWFLAKE_ACCOUNT`, `DMA_SNOWFLAKE_USER`, `DMA_SNOWFLAKE_PRIVATE_KEY_PATH`, `DMA_SNOWFLAKE_ROLE`, `DMA_SNOWFLAKE_WAREHOUSE`, `DMA_TARGET_DATABASE`, `DMA_TARGET_SCHEMA`, and `DMA_RAW_DATABASE`. Use a configured key-pair identity; the example contains environment references only. The supplied example expects a usable private key path; adapt encrypted-key/OAuth settings with your platform owner when required. Source schema overrides are `DMA_RAW_SALES_SCHEMA`, `DMA_RAW_PRODUCTION_SCHEMA`, `DMA_RAW_PERSON_SCHEMA`, and `DMA_RAW_DATE_SCHEMA`; defaults are `RAW_SALES`, `RAW_PRODUCTION`, `RAW_PERSON`, and `RAW_DATE`.

Set a distinct development base schema, for example `DMA_CANDIDATE`. Standard dbt schema generation appends `_BRONZE`, `_SILVER`, and `_GOLD`. Do not change schema-generation macros to remove isolation. These commands assume dbt Core executed outside Snowflake; this is not a qualified dbt Projects on Snowflake upload.

## 4. Validate and build after target authorization

The following commands would contact the selected Snowflake environment; they were not run against a live warehouse in this exercise:

```sh
dbt debug --profiles-dir target/runtime --target snowflake
dbt parse --profiles-dir target/runtime --target snowflake --no-partial-parse
dbt compile --profiles-dir target/runtime --target snowflake --no-partial-parse
dbt build --profiles-dir target/runtime --target snowflake --no-partial-parse
dbt docs generate --profiles-dir target/runtime --target snowflake
```

Reconcile row populations, exact source-grain measures, orphan flags and joins in Snowflake using the captured source catalogue and benchmarks. Check every projected column, permitted/denied roles, performance and costs. Snapshot row totals are test evidence, not production expected volumes or future SLAs. Review full rebuild cost before setting a schedule; no incremental or CDC contract has been invented.

## 5. Connect Omni

Follow [Omni setup](OMNI_SETUP.md). Resolve the provided physical namespace placeholders to the same Gold database/schema. Import native `.view`, `.topic`, `model`, and `relationships` files into an isolated Omni branch. Do not paste unresolved placeholders or replace an existing shared model without review. Refresh the schema, validate content, run the topic-level reconciliation queries, and test actual user access. Keep order, line and reason topics separate. AI context is explanation and guidance; it does not enforce permissions.

## 6. Local replay without Snowflake

The dbt README provides an independent `load_raw.py` path and `requirements-local.txt` for DuckDB. Obtain the exact pinned CSV snapshot from the source reference in `SOURCE_CATALOGUE.md`, verify hashes, then use a new local database path. Source rows and the local database are excluded from the shareable ZIP. The local simulation executes the same dbt logic except the reviewed timestamp adapter branch. It does not prove Snowflake SQL execution, grants or Omni behavior.

## 7. Approval, deployment and recovery

Review unresolved currency/status/discount/history/security decisions with the eventual owner. Approval must bind the exact candidate version. Then ask the user whether to publish a PR or deploy, and to which environment. Use the accelerator deployment workflow for a concrete target plan, separate approval and target evidence. This package records no approval and performs no deployment.

Keep the last accepted consumers on their existing relations while validating the isolated candidate. If a native check fails, retain the candidate for diagnosis and keep the previous accepted version active. Cut over and schedule only after the actual target run, semantic/access checks and owner sign-off. No destructive rollback is automated here.

Official references: [dbt Snowflake configuration](https://docs.getdbt.com/reference/resource-configs/snowflake-configs), [Snowflake adapter release](https://pypi.org/project/dbt-snowflake/1.12.1/), [Omni Snowflake connection](https://docs.omni.co/connect-data/setup/snowflake), [Omni dbt integration](https://docs.omni.co/integrations/dbt).
