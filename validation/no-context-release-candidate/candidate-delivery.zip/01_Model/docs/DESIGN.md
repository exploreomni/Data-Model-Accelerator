# Provisional raw-only dimensional model plan

Plan recorded before candidate generation on 2026-09-24. Evidence boundary: only the 15 selected CSV files, the current accelerator skill and its selected references/scripts. No SME, prior model, Excel analysis or Internet dataset documentation is available. This is a new-model blind exercise; structural proposals are not approved business definitions.

## Confirmed selections and execution scope

dbt targeting Snowflake; existing raw tables are simulated by lexical CSV snapshots. Omni is downstream. Local execution uses dbt Core 1.12.4, dbt-duckdb 1.11 and DuckDB 1.5.5. No Snowflake credentials, native target execution, ingestion replacement or deployment is authorized. Sources are external for Snowflake; a separate offline loader creates local raw schemas from the pinned CSV files. No dbt seeds load production tables.

## Architecture and model decisions

1. Bronze views project every original column as lexical text, preserving empty strings and identifiers. Existing raw storage remains the source of truth. Restricted raw/bronze/silver access is a required deployment gate, not a grant established here.
2. Silver staging applies explicit reviewed numeric/date/boolean conversions. Empty non-key attributes become null; nonempty identifiers remain exact lexical strings to avoid normalization collisions. Decimal precision/scale derives from observed values and conservative proposed bounds. No latest-row selection, CDC, deletions, snapshots or history are fabricated.
3. Silver intermediates combine product hierarchy, customer links, geographic hierarchy and order-line totals without dropping rows. Keys must be unique before joins. Missing relationships remain observable through flags and nullable joined attributes.
4. Gold uses separate order-header and order-line facts, product/customer/geographic/date/payment-type/reason dimensions, and an order/reason bridge. No header financial measures appear on line facts or bridges. Billing and shipping are distinct geography roles. All source lines and bridge records are retained even without a supplied header.
5. Monetary values have UNKNOWN currency and business accounting interpretation. Header source subtotal/tax/freight/total remain distinct from proposed quantity × unit price × (1-discount) line arithmetic. Status codes remain untranslated. No revenue metric, default status exclusion, currency conversion or order-to-reason allocation is approved.
6. Gold is a publication allowlist: no person names, street address, postal code, spatial point, card number, expiry, authorization code, account number, row GUID or person identifier. Customer/address/order identifiers remain linkable pseudonymous operational keys, not anonymization. Card type is sourced without publishing card identifiers.
7. This candidate represents supplied snapshots/current attributes. Full rebuilds are deterministic and reversible from retained raw bytes; historical as-of reporting is unavailable. Source modified times are attributes, not change-event order or ingestion evidence.
8. Date dimension preserves the supplied 731 dates and source calendar attributes. Derived year/month/quarter use actual parsed dates. Prior-year and day-of-week conventions remain source-defined; do not infer fiscal calendar or timezone. Source timestamps are timezone-naive.

## Observed structural evidence

There are 41 lines referencing absent headers; 46 bridge rows covering 23 absent orders; 69 header references missing in each address role; and 17,719 customer/person references lacking supplied person rows. These are source coverage gaps, not proof of corrupt production records. Product/category, state/country, card type and customer/order joins have complete applicable local coverage. Fifteen header subtotals differ from unrounded candidate line arithmetic by at most 0.00005. Preserve both values; do not change rounding to force agreement.

## Validation plan

Profile and hash every source. Test lexical natural keys, composite bridge grain, typed projection evaluation, row/key preservation, orphan flag correctness, left-join fanout, source header arithmetic, candidate line arithmetic, independent fact totals and publication allowlist. Execute every output column by reading complete model projections, including views. Capture pre-execution project hashes, independent dbt parse manifest, full compile/build receipts and complete observed schemas. Run no inferred failing referential integrity test for known source gaps; test gap retention and flag correctness instead. Native Snowflake syntax, grants, performance, Omni behavior and business acceptance remain separate gates.

## Unknown business and operating answers

Currency/FX policy; status meanings; whether line discount is a fraction; financial rounding; sale/revenue recognition; calendar/timezone conventions; source extract completeness; tenant key scope; entity histories and deletes; retention and privacy policy; expected refresh cadence; source and target ownership; semantic access personas; unresolved lookup sources (territory, salesperson role, ship method, offer, currency rate, product model, units). Target database/schema names are placeholders. Any downstream amount use is provisional until these are resolved.
