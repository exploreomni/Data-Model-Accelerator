# Raw source catalogue

This run uses the same pinned 15 CSV files from the earlier blind test: 54,068 rows and 120 fields. Each is a simulated existing Snowflake raw table. No production catalogue, native Snowflake type, role, grant, freshness or replication state was observed. All physical bindings are proposed and must be checked against the actual account.

[Pinned seed directory](https://github.com/Data-Engineer-Camp/dbt-dimensional-modelling/tree/f04d1876137e212e8c133ba75622aeec98bab225/adventureworks/seeds) — only CSV bytes were used; no upstream models, README, solution or previous generated model was supplied to the fresh modeler.

| CSV | Rows | Fields | Simulated source relation |
| --- | ---: | ---: | --- |
| date/date.csv | 731 | 9 | `${DMA_RAW_DATABASE}.${DMA_RAW_DATE_SCHEMA}.DATE` |
| person/address.csv | 1675 | 9 | `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.ADDRESS` |
| person/countryregion.csv | 238 | 3 | `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.COUNTRYREGION` |
| person/person.csv | 2057 | 11 | `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.PERSON` |
| person/stateprovince.csv | 181 | 8 | `${DMA_RAW_DATABASE}.${DMA_RAW_PERSON_SCHEMA}.STATEPROVINCE` |
| production/product.csv | 504 | 20 | `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCT` |
| production/productcategory.csv | 4 | 3 | `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCTCATEGORY` |
| production/productsubcategory.csv | 37 | 4 | `${DMA_RAW_DATABASE}.${DMA_RAW_PRODUCTION_SCHEMA}.PRODUCTSUBCATEGORY` |
| sales/creditcard.csv | 19118 | 6 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.CREDITCARD` |
| sales/customer.csv | 19820 | 4 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.CUSTOMER` |
| sales/salesorderdetail.csv | 5716 | 9 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERDETAIL` |
| sales/salesorderheader.csv | 1566 | 23 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERHEADER` |
| sales/salesorderheadersalesreason.csv | 1710 | 3 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESORDERHEADERSALESREASON` |
| sales/salesreason.csv | 10 | 4 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.SALESREASON` |
| sales/store.csv | 701 | 4 | `${DMA_RAW_DATABASE}.${DMA_RAW_SALES_SCHEMA}.STORE` |

Raw columns are loaded lexically in the local simulation. Blank strings stay blank in bronze; literal codes such as NA are retained. The exact source hashes and per-column empty/distinct counts are in the catalogue JSON. No source data rows or local database are shipped in the shareable ZIP.

Observed source relationships are scoped to the extract. Missing headers, addresses and people may reflect incomplete sampling; do not infer deletion, fraud, invalid business records or production orphan rates. No extra source tables were discovered by reading the original repository.

The business domain is inferred from source labels and structure. Currency, status meaning, financial policy, timezone, tenant key scope and historical rules cannot be established from those labels.
