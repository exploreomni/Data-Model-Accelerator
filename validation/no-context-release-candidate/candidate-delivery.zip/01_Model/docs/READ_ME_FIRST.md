# Your source-only model handoff

Open `START_HERE.html` in the ZIP root. Begin with the model and decisions, then inspect validation and implementation files. This delivery is designed for an analytics engineer who inherited raw data without SMEs or usable Excel reports.

**Delivered:** 43 dbt models (15 Bronze, 19 Silver, 9 Gold), a dictionary for all 58 scoped objects / 513 columns, connected architecture and layer ERDs, three native Omni topics, and portable plus embedded AI context.

**Verified locally:** 105 dbt tests; full source population/value comparisons; every projected column; actual Omni measure/join/topic replay; deliberately introduced fanout, amount, missing-row, wrong-date and field-exposure defects. dbt-snowflake also parsed/compiled the project offline. SQLFluff ran all rules; 415 exact-file convention exceptions preserve source naming, stable column order or framework formatting. Raw findings remain available.

**Pending:** real Snowflake connectivity/build/catalogue/access, native Omni import/query/AI behavior, and human business acceptance. A test pass is not an approved currency, revenue, status or historical model.

## Where to go

- [Architecture and gold table diagram](ARCHITECTURE.svg)
- [Bronze](BRONZE.md), [Silver](SILVER.md), [Gold](GOLD.md)
- [Data dictionary](DATA_DICTIONARY.md)
- [Source catalogue](SOURCE_CATALOGUE.md)
- [Copy/paste setup and runbook](RUNBOOK.md)
- [Omni setup](OMNI_SETUP.md) and [AI context](AI_CONTEXT.md)
- [Independent validation](../../03_Validation/validation/INDEPENDENT_REVIEW.md)

The dbt scripts are in `02_Implementation/dbt_project/models/`, split into `bronze`, `silver`, and `gold`. Tests, macros, source declarations and profile example sit alongside them. Omni code is in `02_Implementation/omni/`. Source CSV rows and working databases are intentionally outside this shareable package; the source manifest records the exact public snapshot for an optional local replay.

After the candidate is reviewed and revised as needed, the next decision is whether to publish a PR or deploy to a specified development environment. No sign-off, deployment or merge has happened in this exercise.
