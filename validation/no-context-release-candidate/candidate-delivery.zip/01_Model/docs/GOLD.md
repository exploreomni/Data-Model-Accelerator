# Gold model contract

Nine tables publish six dimensions, two facts and one bridge. Orders retain all supplied headers; lines retain every supplied detail, including 41 missing-header lines. The bridge retains all 1,710 associations, including 46 with no supplied header. Six dimensions provide product, customer, geography, calendar date, payment-type and reason attributes. Header amounts never appear on line or reason grain. No financial allocation by reason is invented. Currency is unknown, so amount totals remain structural benchmarks, not approved financial KPIs.

## Operations and evidence

Run order follows dbt source/ref dependencies: external raw → bronze → silver staging → silver intermediates → gold. Bronze and silver are views; gold tables rebuild from the current supplied snapshots. No incremental schedule or production SLA is configured. Source modified timestamps do not establish freshness, CDC order or history. Late arrivals are reflected on a later full rebuild; deletes/history cannot be inferred from one extract.

Business and operational owners, tenant boundaries, retention, timezone, currency and access personas are unknown. Restrict raw/bronze/silver; only reviewed gold relations may be granted to the Omni role. Consumer identifiers remain linkable. Local allowlist checks do not establish actual Snowflake grants or masking.

Recovery: keep the pinned raw snapshot and last accepted code; build an isolated development schema, compare the independent benchmark, then cut over consumers only after separate target and owner approval. On failure keep consumers on the previous accepted relations. No destructive rollback SQL is included.

Monitoring before live use: failed casts and keys, complete row populations, orphan rates, amount reconciliation, schema drift, source freshness and allowed/denied access personas. Known source gaps are reported, not automatically repaired.

See [the complete column dictionary](DATA_DICTIONARY.md), [the layer ERD](ERD_GOLD.svg), [the deployment runbook](RUNBOOK.md), and [AI context](AI_CONTEXT.md).

## Object contracts

### dim_products

One supplied product; current hierarchy only; restricted identifiers remain linkable

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_PRODUCTS`
- Grain: One supplied product; current hierarchy only
- Key: product_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: int_products
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### dim_customers

One supplied customer; no name or person ID publication; restricted identifiers remain linkable

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_CUSTOMERS`
- Grain: One supplied customer; no name or person ID publication
- Key: customer_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: int_customers
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### dim_geographies

One supplied address ID; geographic area only, no street/postal/spatial fields; restricted identifiers remain linkable

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_GEOGRAPHIES`
- Grain: One supplied address ID; geographic area only, no street/postal/spatial fields
- Key: address_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: int_geographies
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### dim_sales_reasons

One supplied sales reason; meaning inferred from source labels

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_SALES_REASONS`
- Grain: One supplied sales reason; meaning inferred from source labels
- Key: sales_reason_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__salesreason
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### dim_date

Supplied date dimension plus factual calendar year/month/quarter; source weekday/year-over-year conventions retained

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_DATE`
- Grain: One supplied calendar date, 2011-01-01 to 2012-12-31; no extension invented
- Key: date_day (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_date__date
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### dim_payment_types

Non-sensitive card-type vocabulary; excludes card identifiers, numbers and expiry

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.DIM_PAYMENT_TYPES`
- Grain: One distinct observed non-null card-type label
- Key: payment_card_type (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__creditcard
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### fct_orders

One supplied order header; source header measures occur only once per order

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.FCT_ORDERS`
- Grain: One supplied order header; source header measures occur only once per order
- Key: order_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__salesorderheader, int_order_line_totals, stg_sales__customer, stg_person__address, stg_sales__creditcard
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### fct_order_lines

One supplied order detail; orphan lines retained with nullable header context

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.FCT_ORDER_LINES`
- Grain: One supplied order detail; orphan lines retained with nullable header context
- Key: order_line_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__salesorderdetail, stg_sales__salesorderheader, stg_production__product
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### bridge_order_sales_reasons

One supplied order/reason association; no allocated financial measure

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_GOLD.BRIDGE_ORDER_SALES_REASONS`
- Grain: One supplied order/reason association; no allocated financial measure
- Key: order_id, sales_reason_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__salesorderheadersalesreason, stg_sales__salesorderheader
 - Materialization: table
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

