# Silver model contract

Fifteen staging views apply explicit typing; four intermediates prepare current product, customer and geographic context plus line totals before any header join. IDs remain lexical strings. Empty attributes may become null according to each column expression. Invalid nonempty casts fail; no bad row is silently quarantined or dropped. Duplicate natural keys fail tests before safe joins are accepted. No arbitrary deduplication, SCD, delete or tenant logic is inferred.

## Operations and evidence

Run order follows dbt source/ref dependencies: external raw → bronze → silver staging → silver intermediates → gold. Bronze and silver are views; gold tables rebuild from the current supplied snapshots. No incremental schedule or production SLA is configured. Source modified timestamps do not establish freshness, CDC order or history. Late arrivals are reflected on a later full rebuild; deletes/history cannot be inferred from one extract.

Business and operational owners, tenant boundaries, retention, timezone, currency and access personas are unknown. Restrict raw/bronze/silver; only reviewed gold relations may be granted to the Omni role. Consumer identifiers remain linkable. Local allowlist checks do not establish actual Snowflake grants or masking.

Recovery: keep the pinned raw snapshot and last accepted code; build an isolated development schema, compare the independent benchmark, then cut over consumers only after separate target and owner approval. On failure keep consumers on the previous accepted relations. No destructive rollback SQL is included.

Monitoring before live use: failed casts and keys, complete row populations, orphan rates, amount reconciliation, schema drift, source freshness and allowed/denied access personas. Known source gaps are reported, not automatically repaired.

See [the complete column dictionary](DATA_DICTIONARY.md), [the layer ERD](ERD_SILVER.svg), [the deployment runbook](RUNBOOK.md), and [AI context](AI_CONTEXT.md).

## Object contracts

### stg_date__date

Explicitly typed snapshot of date.date

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_DATE__DATE`
- Grain: One supplied date.date snapshot row; no deduplication or history reconstruction
- Key: date_day (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_date__date
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_person__address

Explicitly typed snapshot of person.address

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PERSON__ADDRESS`
- Grain: One supplied person.address snapshot row; no deduplication or history reconstruction
- Key: addressid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_person__address
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_person__countryregion

Explicitly typed snapshot of person.countryregion

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PERSON__COUNTRYREGION`
- Grain: One supplied person.countryregion snapshot row; no deduplication or history reconstruction
- Key: countryregioncode (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_person__countryregion
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_person__person

Explicitly typed snapshot of person.person

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PERSON__PERSON`
- Grain: One supplied person.person snapshot row; no deduplication or history reconstruction
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_person__person
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_person__stateprovince

Explicitly typed snapshot of person.stateprovince

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PERSON__STATEPROVINCE`
- Grain: One supplied person.stateprovince snapshot row; no deduplication or history reconstruction
- Key: stateprovinceid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_person__stateprovince
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_production__product

Explicitly typed snapshot of production.product

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PRODUCTION__PRODUCT`
- Grain: One supplied production.product snapshot row; no deduplication or history reconstruction
- Key: productid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_production__product
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_production__productcategory

Explicitly typed snapshot of production.productcategory

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PRODUCTION__PRODUCTCATEGORY`
- Grain: One supplied production.productcategory snapshot row; no deduplication or history reconstruction
- Key: productcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_production__productcategory
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_production__productsubcategory

Explicitly typed snapshot of production.productsubcategory

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_PRODUCTION__PRODUCTSUBCATEGORY`
- Grain: One supplied production.productsubcategory snapshot row; no deduplication or history reconstruction
- Key: productsubcategoryid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_production__productsubcategory
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__creditcard

Explicitly typed snapshot of sales.creditcard

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__CREDITCARD`
- Grain: One supplied sales.creditcard snapshot row; no deduplication or history reconstruction
- Key: creditcardid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__creditcard
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__customer

Explicitly typed snapshot of sales.customer

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__CUSTOMER`
- Grain: One supplied sales.customer snapshot row; no deduplication or history reconstruction
- Key: customerid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__customer
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__salesorderdetail

Explicitly typed snapshot of sales.salesorderdetail

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__SALESORDERDETAIL`
- Grain: One supplied sales.salesorderdetail snapshot row; no deduplication or history reconstruction
- Key: salesorderdetailid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__salesorderdetail
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__salesorderheader

Explicitly typed snapshot of sales.salesorderheader

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__SALESORDERHEADER`
- Grain: One supplied sales.salesorderheader snapshot row; no deduplication or history reconstruction
- Key: salesorderid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__salesorderheader
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__salesorderheadersalesreason

Explicitly typed snapshot of sales.salesorderheadersalesreason

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__SALESORDERHEADERSALESREASON`
- Grain: One supplied sales.salesorderheadersalesreason snapshot row; no deduplication or history reconstruction
- Key: salesorderid, salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__salesorderheadersalesreason
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__salesreason

Explicitly typed snapshot of sales.salesreason

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__SALESREASON`
- Grain: One supplied sales.salesreason snapshot row; no deduplication or history reconstruction
- Key: salesreasonid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__salesreason
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### stg_sales__store

Explicitly typed snapshot of sales.store

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.STG_SALES__STORE`
- Grain: One supplied sales.store snapshot row; no deduplication or history reconstruction
- Key: businessentityid (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: br_sales__store
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### int_products

One supplied product; current hierarchy only

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.INT_PRODUCTS`
- Grain: One supplied product; current hierarchy only
- Key: product_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_production__product, stg_production__productsubcategory, stg_production__productcategory
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### int_customers

One supplied customer; no name or person ID publication

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.INT_CUSTOMERS`
- Grain: One supplied customer; no name or person ID publication
- Key: customer_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__customer, stg_person__person, stg_sales__store
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### int_geographies

One supplied address ID; geographic area only, no street/postal/spatial fields

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.INT_GEOGRAPHIES`
- Grain: One supplied address ID; geographic area only, no street/postal/spatial fields
- Key: address_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_person__address, stg_person__stateprovince, stg_person__countryregion
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

### int_order_line_totals

Line-only aggregation before any header or reason join

- Physical: `${DMA_TARGET_DATABASE}.${DMA_TARGET_SCHEMA}_SILVER.INT_ORDER_LINE_TOTALS`
- Grain: One order ID represented in supplied lines; includes orders absent from header
- Key: order_id (candidate; tested within supplied extract, not a global identity guarantee)
- Inputs: stg_sales__salesorderdetail
 - Materialization: view
- Refresh/history: Proposed full rebuild; cadence unknown; Supplied snapshot only; current attributes, no SCD or event history
- Ownership: Unknown; no SME available
- Recovery: Rebuild from retained pinned raw snapshot in isolated schema; retain prior artifacts for rollback

