# Omni development setup

**Candidate only — native Omni import, Snowflake execution, permissions and AI query acceptance are not established.** This exercise has no supplied Snowflake or Omni credentials. No tenant was connected, modified or queried.

This package uses native Omni YAML file shapes: `model`, `relationships`, `*.view` and `*.topic`. These files are not a dashboard export, a live model ID, or an Omni validation receipt. The static report is `03_Validation/validation/omni-static.json`; it validates this deliberately bounded package against `02_Implementation/contracts/model-contract.json`. Omni must still validate the resolved development model. [YAML files](https://docs.omni.co/api/models/create-or-update-yaml-files), [native model validation](https://docs.omni.co/api/models/validate-model).

## Resolve the actual destination

The dbt project uses `DMA_TARGET_DATABASE` and `DMA_TARGET_SCHEMA` (base-schema default `DMA_CANDIDATE`). Gold objects live in `${DMA_TARGET_SCHEMA}_GOLD`. Candidate native views contain the literal packaging values `__DMA_TARGET_DATABASE__` and `__DMA_TARGET_SCHEMA___GOLD`; Omni will not expand these values. The local preparation tool writes a separate resolved copy.

From the extracted ZIP root, replace the example database/schema with the actual approved development values, then run:

```sh
python -m pip install -r 02_Implementation/tools/requirements-omni.txt
export DMA_TARGET_DATABASE="YOUR_DEV_DATABASE"
export DMA_TARGET_SCHEMA="YOUR_DEV_BASE_SCHEMA"
python 02_Implementation/omni/configure_environment.py --output /tmp/omni-resolved-review
python 02_Implementation/tools/validate_omni.py --contract 02_Implementation/contracts/model-contract.json --omni-dir /tmp/omni-resolved-review --output /tmp/omni-resolved-static.json --negative-controls
```

The output path must be new or empty and outside the source package. `YOUR_DEV_DATABASE` and `YOUR_DEV_BASE_SCHEMA` are documentation examples, not provisioned destinations. Install this tool's local dependencies from your approved package source: PyYAML 6.0.3 and sqlglot 30.18.0; Python 3.12 was used for this run. Neither command accesses Snowflake or Omni. The preparation tool accepts ordinary uppercase Snowflake identifiers; quoted mixed-case identifiers require a reviewed mapping change.

There are **9 views, 3 topics, 11 relationships and 15 measures**, with **99 consumer dimensions**. Native files are `model`, `relationships`, the nine `.view` files and three `.topic` files. Upload/import only those native files. `semantic-bindings.json` is the local contract adapter used by the validator; `configure_environment.py` and this package's other support files are not Omni YAML.

## Connection and deployment order

1. Review the new model contract, unresolved definitions and publication exclusions. Build the selected dbt project into an isolated Snowflake development destination using its documented environment configuration. Execute the data, projection, uniqueness, relationship and reconciliation checks there. Local simulation is separate evidence.
2. Have a Snowflake administrator provision an Omni read role for the approved gold objects and warehouse. The role must not read raw or staging person, address, payment-card or account data. Do not use broad future-schema grants merely because they appear in a general setup example. Configure the real account identifier, warehouse, role, username and approved authentication through Omni connection settings; keep secrets out of this package. An Omni Organization Admin creates and tests the connection. [Snowflake setup](https://docs.omni.co/connect-data/setup/snowflake).
3. Resolve every candidate database/schema placeholder to the actual destination using the included local environment preparation tool. The placeholder strings are packaging tokens, **not Omni environment-variable syntax**. Resolved files contain ordinary string values in `catalog`, `schema` and `table_name`. Confirm Snowflake object and column case against the actual built catalogue. [Catalog](https://docs.omni.co/modeling/views/parameters/catalog), [schema](https://docs.omni.co/modeling/views/parameters/schema), [table name](https://docs.omni.co/modeling/views/parameters/table-name).
4. Refresh the development connection schema, then map the candidate views to the actual generated model view names. Where Omni already generated a matching view, apply the reviewed overlay to that view instead of creating a second name for the same table. Update all dependent references consistently. Add the candidate YAML to an isolated development branch using the model IDE or a reviewed YAML change workflow, preserving current checksums if the API is used. Do not replace an existing shared model wholesale. [YAML change contract](https://docs.omni.co/api/models/create-or-update-yaml-files).
5. Run Omni's native validation on that exact branch. Then execute the source-bound queries listed in `AI_CONTEXT.md`, including every join role and empty/filter boundary, and compare the returned results against the frozen independent expectations. Record model, branch, input snapshot and query evidence. Do not label local SQL comparisons as an Omni query run.
6. Test the effective consumer role: unauthorized raw/person/card fields must be inaccessible through modeled queries and any permitted SQL surface. Review the automatically generated schema model as well as these curated topics. Topic field restrictions and AI curation do not replace warehouse authorization.
7. Obtain definition, access and query-result acceptance before shared-model promotion. Promotion is outside this exercise.

## Optional dbt integration

Omni can query already-built Snowflake objects without this optional metadata integration. To connect dbt, connect the Git repository holding the dbt project, configure the Omni dbt environment to mirror the selected `profiles.yml` output (or dbt Cloud environment), then sync. Keep database, schema, target, project path and required environment variables aligned. The integration reads a compiled manifest to match models to physical views; a YAML file in this package does not establish a live dbt integration. [dbt overview](https://docs.omni.co/integrations/dbt), [repository setup](https://docs.omni.co/integrations/dbt/setup), [environment settings](https://docs.omni.co/integrations/dbt/environments).

A dbt sync refreshes manifest-derived metadata; a schema refresh inspects structural warehouse changes and, when dbt is configured, also syncs dbt. After the first real build, refresh the schema before checking model matching. Keep the dbt and Omni model repositories separate when publishing the implementation. [Sync behavior](https://docs.omni.co/integrations/dbt/syncing-dbt), [repository guidance](https://docs.omni.co/integrations/dbt/setup).

## AI context and enforcement

`AI_CONTEXT.md` is portable guidance for Claude, Codex, Gemini or another analyst agent. The native `ai_context` fields in the model, views, topics and measures carry the same domain restrictions inside Omni. No standalone invented `agent_instructions` parameter is used. [Model context](https://docs.omni.co/modeling/models/ai-context), [topic context](https://docs.omni.co/modeling/topics/parameters/ai-context), [view context](https://docs.omni.co/modeling/views/parameters/ai-context), [measure context](https://docs.omni.co/modeling/measures/parameters/ai-context).

`ai_chat_topics` and `ai_fields` curate AI awareness. They are not security controls. Explicit topic `fields` lists restrict that topic's runtime field selection, but do not grant or remove access to other topics, raw SQL or other models. `hidden` affects presentation and does not protect data. The warehouse role, Omni permissions, publication allowlist and negative access tests jointly establish the intended boundary. [AI topic curation](https://docs.omni.co/modeling/models/ai-chat-topics), [AI fields](https://docs.omni.co/modeling/topics/parameters/ai-fields), [topic fields](https://docs.omni.co/modeling/topics/parameters/fields).

## Static check scope

The accelerator's existing `e2e_semantics.py` was inspected, but it is explicitly a fixed invoices/customers regression adapter. Applying it to this new multi-view source would require unsupported assumptions. The supplied `02_Implementation/tools/validate_omni.py` instead checks native filenames and allowed parameters, physical column bindings and numeric measure inputs, exact references, primary-key declarations, approved join edges and topic isolation against this exercise's contract. It is not Omni's native parser or runtime.

Official documentation checked on 2026-09-24. This document describes the documented parameters used by the package; it makes no claim about an untested tenant or feature entitlement.
