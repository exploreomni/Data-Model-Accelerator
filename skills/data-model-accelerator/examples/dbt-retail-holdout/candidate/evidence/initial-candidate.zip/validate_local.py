"""Run only the reviewed candidate with local dbt-duckdb; write evidence below candidate."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys,importlib.metadata
from evaluator import ROOT,validate_raw,load_raw,connect,evaluate


def main():
    runtime=ROOT/'runtime';runtime.mkdir(exist_ok=True)
    raw=json.loads((ROOT.parent/'input/raw-data.json').read_text());tables=validate_raw(raw)
    db=runtime/'DMA_RETAIL.duckdb'
    if db.exists():db.unlink()
    con=connect(db);load_raw(con,tables);con.close()
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    env=dict(os.environ,DBT_SEND_ANONYMOUS_USAGE_STATS='false',DO_NOT_TRACK='1')
    prefix=['/private/tmp/dma-native-dbt-env/bin/dbt','--no-use-colors','--log-path',str(runtime/'logs')]
    common=['--project-dir',str(ROOT/'dbt'),'--profiles-dir',str(ROOT/'dbt/profiles'),'--target','local','--target-path',str(runtime/'dbt-target'),'--no-partial-parse']
    checks=[]
    for name,args in [('source_data_tests',['test','--select','tag:raw']),('native_dbt_run',['run']),('all_data_tests',['test'])]:
        cmd=prefix+args+common
        run=subprocess.run(cmd,env=env,text=True,capture_output=True,cwd=ROOT,timeout=120)
        (evidence/(name+'.txt')).write_text(run.stdout+run.stderr)
        checks.append({'id':name,'command':cmd,'exit_code':run.returncode,'status':'pass' if run.returncode==0 else 'fail','evidence':name+'.txt'})
        if run.returncode:break
    result={'checked_at':datetime.now(timezone.utc).isoformat(),'environment':'isolated dbt-duckdb; no Snowflake/Omni execution','versions':{n:importlib.metadata.version(n) for n in ['dbt-core','dbt-duckdb','duckdb','jinja2']},'checks':checks}
    if len(checks)==3 and all(c['status']=='pass' for c in checks):
        from evaluator import rows
        con=connect(db)
        gold=rows(con,'SELECT * FROM DMA_RETAIL.GOLD.FCT_ORDER_LINE_FULFILLMENT ORDER BY TENANT_ID,ORDER_ID,LINE_ID')
        report=rows(con,'SELECT * FROM DMA_RETAIL.REPORTS.RETAIL_FULFILLMENT_SUMMARY ORDER BY ORDER_MONTH,PRODUCT_ID')
        con.close();native={'gold':gold,'report':report};replayed=evaluate(raw,{})
        assert native==replayed,'Native dbt output differs from template evaluator'
        (evidence/'native-dbt-output.json').write_text(json.dumps(native,indent=2)+'\n')
        result['native_vs_evaluator']='pass'
    (evidence/'native-dbt-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if len(checks)==3 and all(c['status']=='pass' for c in checks) else 1
if __name__=='__main__':sys.exit(main())
